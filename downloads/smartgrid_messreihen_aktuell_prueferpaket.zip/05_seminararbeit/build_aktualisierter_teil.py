from __future__ import annotations

import csv
import json
import math
import re
from collections import defaultdict
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "05_seminararbeit"
CHART_DIR = OUT_DIR / "charts_aktuell"
CHART_DIR.mkdir(parents=True, exist_ok=True)
DOCX_PATH = OUT_DIR / "Seminararbeit_Teil_Modell_und_Messreihen_aktualisiert.docx"
SOURCE_XLSX_PATH = OUT_DIR / "Detailquellenblatt.xlsx"

MASTER_INDEX = ROOT / "00_ueberblick" / "master_index.csv"
AGG_CSV = ROOT / "00_ueberblick" / "aggregate_by_series_controller.csv"


SOURCE_REFERENCES = [
    {
        "id": "Q1",
        "type": "Eigene Primaerquelle",
        "source": "sgsim-Codebase und Projektdokumentation",
        "detail": "docs/architecture.md, docs/components.md, docs/controllers.md, docs/methodology.md sowie src/sgsim/",
        "used_for": "Modellaufbau, Komponenten, Controllerlogik, Vorzeichenkonvention, CLI-Persistenz",
        "note": "Diese Quelle ist die fachliche Grundlage fuer die Beschreibung der eigenen Simulation.",
    },
    {
        "id": "Q2",
        "type": "Eigene Primaerquelle",
        "source": "Geordnete Messreihen im Repository",
        "detail": "smartgrid_messreihen/00_ueberblick/master_index.csv und aggregate_by_series_controller.csv",
        "used_for": "Alle Zahlen zu Brownouts, unserved energy, Surplus, Frequenzabweichung und Kosten",
        "note": "Die Diagramme und Tabellen des Dokuments wurden direkt aus diesen Dateien erzeugt.",
    },
    {
        "id": "Q3",
        "type": "Externe Hintergrundquelle",
        "source": "OpenStax: University Physics Volume 2, Abschnitt 9.5 Electrical Energy and Power",
        "detail": "https://openstax.org/books/university-physics-volume-2/pages/9-5-electrical-energy-and-power",
        "used_for": "Grundlagen zu elektrischer Leistung, Energieumwandlung und Leistung als Energie pro Zeit",
        "note": "Nur fuer physikalische Grundbegriffe genutzt, nicht fuer Messwerte.",
    },
    {
        "id": "Q4",
        "type": "Externe Hintergrundquelle",
        "source": "U.S. Department of Energy: Solar Integration - Solar Energy and Storage Basics",
        "detail": "https://www.energy.gov/cmei/systems/solar-integration-solar-energy-and-storage-basics",
        "used_for": "Einordnung, warum Speicher bei Solarenergie und Lastspitzen noetig sind",
        "note": "Unterstuetzt die allgemeine Speichererklaerung.",
    },
    {
        "id": "Q5",
        "type": "Externe Hintergrundquelle",
        "source": "U.S. Department of Energy: How Pumped Storage Hydropower Works",
        "detail": "https://www.energy.gov/cmei/water/how-pumped-storage-hydropower-works",
        "used_for": "Einordnung von Pumpspeicher als etablierter Langzeitspeichertechnologie",
        "note": "Nur Hintergrund, keine Kalibrierung des Simulators.",
    },
    {
        "id": "Q6",
        "type": "Externe Hintergrundquelle",
        "source": "International Energy Agency: Electrolysers",
        "detail": "https://www.iea.org/energy-system/lowemission-fuels/electrolysers",
        "used_for": "Elektrolyseure, Wasserstoff aus Strom und flexible Kopplung an variable erneuerbare Energie",
        "note": "Unterstuetzt die Beschreibung der H2-Kette, keine Ergebnisquelle.",
    },
    {
        "id": "Q7",
        "type": "Externe technische Quelle",
        "source": "ENTSO-E: Frequency Stability Evaluation - Criteria for the Synchronous Zone of Continental Europe",
        "detail": "https://www.entsoe.eu/Documents/SOC%20documents/RGCE_SPD_frequency_stability_criteria_v10.pdf",
        "used_for": "Einordnung von Frequenzabweichung, Erzeugung-Last-Ungleichgewicht und vereinfachter Stabilitaetsbetrachtung",
        "note": "Die Seminararbeit nutzt daraus nur den Grundzusammenhang, nicht die detaillierten Netzmodelle.",
    },
    {
        "id": "Q8",
        "type": "Externe wirtschaftliche Quelle",
        "source": "Joint Research Centre / EU Publications Office: Societal appreciation of energy security - Value of Lost Load",
        "detail": "https://ses.jrc.ec.europa.eu/publications-list/societal-appreciation-energy-security-volume-4-value-lost-load-greece",
        "used_for": "Begriff Value of Lost Load als wirtschaftliche Bewertung nicht gelieferter Energie",
        "note": "Der konkrete VoLL-Wert im Simulator ist eine Modellannahme; die Quelle stuetzt nur das Konzept.",
    },
    {
        "id": "Q9",
        "type": "Externe Datenquelle zur Einordnung",
        "source": "Fraunhofer ISE: Renewable Energy Data / Energy Charts",
        "detail": "https://www.ise.fraunhofer.de/en/renewable-energy-data.html",
        "used_for": "Hinweis, dass reale Stromdaten fuer spaetere Arbeiten aus etablierten Datenplattformen kommen koennen",
        "note": "Nicht als Zahlenbasis fuer die Simulation verwendet.",
    },
]


PRETTY_REPLACEMENTS = [
    ("Wetterabhaengigkeit", "Wetterabhängigkeit"),
    ("Wetterverlaeufe", "Wetterverläufe"),
    ("Frequenzstabilitaet", "Frequenzstabilität"),
    ("Stabilitaetsbetrachtung", "Stabilitätsbetrachtung"),
    ("Netzstabilitaetsrechnung", "Netzstabilitätsrechnung"),
    ("Stabilitaetsindikator", "Stabilitätsindikator"),
    ("Stabilitaetscheck", "Stabilitätscheck"),
    ("Frequenzauswertung", "Frequenzauswertung"),
    ("Frequenzeinordnung", "Frequenzeinordnung"),
    ("Frequenzabweichungen", "Frequenzabweichungen"),
    ("Frequenzabweichung", "Frequenzabweichung"),
    ("Wasserstoff-Gasturbine", "Wasserstoff-Gasturbine"),
    ("Speicherfuellstaende", "Speicherfüllstände"),
    ("Speicherfuellstand", "Speicherfüllstand"),
    ("Speichererklaerung", "Speichererklärung"),
    ("Wasserstoffspeicher", "Wasserstoffspeicher"),
    ("Value-of-Lost-Load-Kosten", "Value-of-Lost-Load-Kosten"),
    ("Simulationslaeufen", "Simulationsläufen"),
    ("Simulationslaeufe", "Simulationsläufe"),
    ("Codex-Operator-Laeufe", "Codex-Operator-Läufe"),
    ("Claude-Live-Laeufe", "Claude-Live-Läufe"),
    ("Claude-Laeufe", "Claude-Läufe"),
    ("Baseline-Laeufe", "Baseline-Läufe"),
    ("Codex-Durchgaenge", "Codex-Durchgänge"),
    ("Codex-Laeufe", "Codex-Läufe"),
    ("KI-Laeufen", "KI-Läufen"),
    ("Einzellaeufe", "Einzelläufe"),
    ("Detailquellenblatt", "Detailquellenblatt"),
    ("Detailquellen", "Detailquellen"),
    ("Quellenhinweis", "Quellenhinweis"),
    ("Quellenblatt", "Quellenblatt"),
    ("Hintergrundquellen", "Hintergrundquellen"),
    ("Hintergrundquelle", "Hintergrundquelle"),
    ("Hintergruende", "Hintergründe"),
    ("Primaerquellen", "Primärquellen"),
    ("Primaerquelle", "Primärquelle"),
    ("Ergebnisquelle", "Ergebnisquelle"),
    ("Datenquellen", "Datenquellen"),
    ("Datenquelle", "Datenquelle"),
    ("Vollstaendige", "Vollständige"),
    ("vollstaendige", "vollständige"),
    ("vollstaendige", "vollständige"),
    ("Zusammenhaenge", "Zusammenhänge"),
    ("zusammenhaengende", "zusammenhängende"),
    ("Zielgroessen", "Zielgrößen"),
    ("Stellgroessen", "Stellgrößen"),
    ("Messgroessen", "Messgrößen"),
    ("Messgroesse", "Messgröße"),
    ("Kostensaeule", "Kostensäule"),
    ("Modulflaeche", "Modulfläche"),
    ("Ortsabhaengigkeit", "Ortsabhängigkeit"),
    ("Plausibilitaet", "Plausibilität"),
    ("Prioritaeten", "Prioritäten"),
    ("Rentabilitaet", "Rentabilität"),
    ("Stabilitaet", "Stabilität"),
    ("Realitaet", "Realität"),
    ("Pruefer", "Prüfer"),
    ("Pruefung", "Prüfung"),
    ("Erklaerung", "Erklärung"),
    ("Veroeffentlichung", "Veröffentlichung"),
    ("Moeglichkeiten", "Möglichkeiten"),
    ("Aenderungen", "Änderungen"),
    ("Anfangszustaende", "Anfangszustände"),
    ("Auffaellig", "Auffällig"),
    ("Ausfaelle", "Ausfälle"),
    ("Datensaetze", "Datensätze"),
    ("Droop-Naehung", "Droop-Näherung"),
    ("Durchgaenge", "Durchgänge"),
    ("Engpaesse", "Engpässe"),
    ("Geaendert", "Geändert"),
    ("Geschaefte", "Geschäfte"),
    ("Gespraech", "Gespräch"),
    ("Groessen", "Größen"),
    ("Groesse", "Größe"),
    ("Markterloese", "Markterlöse"),
    ("Naeherung", "Näherung"),
    ("Netzengpaesse", "Netzengpässe"),
    ("Schaetzungen", "Schätzungen"),
    ("Ueberarbeitung", "Überarbeitung"),
    ("Ueberlegenheit", "Überlegenheit"),
    ("Ueberschussenergie", "Überschussenergie"),
    ("Ueberschussstrom", "Überschussstrom"),
    ("Ueberschuesse", "Überschüsse"),
    ("Ueberschuss", "Überschuss"),
    ("Unterstuetzt", "Unterstützt"),
    ("Waermepumpen", "Wärmepumpen"),
    ("Waerme", "Wärme"),
    ("Dafuer", "Dafür"),
    ("Fuer", "Für"),
    ("Saeule", "Säule"),
    ("Staerke", "Stärke"),
    ("Ueber", "Über"),
    ("Laeufe", "Läufe"),
    ("aussagekraeftiger", "aussagekräftiger"),
    ("eigenstaendiger", "eigenständiger"),
    ("zusammenhaengende", "zusammenhängende"),
    ("zurueckgehalten", "zurückgehalten"),
    ("zurueckspeisen", "zurückspeisen"),
    ("uebersichtlichen", "übersichtlichen"),
    ("ueberprueft", "überprüft"),
    ("uebertrifft", "übertrifft"),
    ("ueberhaupt", "überhaupt"),
    ("vollstaendige", "vollständige"),
    ("zahlenmaessig", "zahlenmäßig"),
    ("gluecklichere", "glücklichere"),
    ("glaubwuerdiger", "glaubwürdiger"),
    ("endgueltigen", "endgültigen"),
    ("verstaendlich", "verständlich"),
    ("zukuenftige", "zukünftige"),
    ("zuverlaessig", "zuverlässig"),
    ("zusaetzlich", "zusätzlich"),
    ("gegenueber", "gegenüber"),
    ("grundsaetzlich", "grundsätzlich"),
    ("verfuegbar", "verfügbar"),
    ("veraendern", "verändern"),
    ("veraendert", "verändert"),
    ("unguenstige", "ungünstige"),
    ("unguenstig", "ungünstig"),
    ("ungefaehr", "ungefähr"),
    ("tagsueber", "tagsüber"),
    ("ausgefuehrte", "ausgeführte"),
    ("ausgefuehrt", "ausgeführt"),
    ("ausfuehren", "ausführen"),
    ("gefaehrlich", "gefährlich"),
    ("bestaetigt", "bestätigt"),
    ("gestuetzt", "gestützt"),
    ("gezaehlt", "gezählt"),
    ("erzaehlt", "erzählt"),
    ("erklaeren", "erklären"),
    ("erklaert", "erklärt"),
    ("gehoeren", "gehören"),
    ("entlaedt", "entlädt"),
    ("enthaelt", "enthält"),
    ("aehnliche", "ähnliche"),
    ("aehnlich", "ähnlich"),
    ("aendern", "ändern"),
    ("dafuer", "dafür"),
    ("duerfen", "dürfen"),
    ("frueh", "früh"),
    ("fuehrt", "führt"),
    ("fuer", "für"),
    ("haeufiger", "häufiger"),
    ("hoeherer", "höherer"),
    ("koennen", "können"),
    ("koennte", "könnte"),
    ("laengere", "längere"),
    ("moeglichen", "möglichen"),
    ("moeglichst", "möglichst"),
    ("muesste", "müsste"),
    ("muessen", "müssen"),
    ("naechsten", "nächsten"),
    ("naechste", "nächste"),
    ("nuetzlicher", "nützlicher"),
    ("nuetzlich", "nützlich"),
    ("pruefbar", "prüfbar"),
    ("prueft", "prüft"),
    ("spaeteren", "späteren"),
    ("spaetere", "spätere"),
    ("spaeter", "später"),
    ("staerker", "stärker"),
    ("stuetzt", "stützt"),
    ("traeger", "träger"),
    ("waehrend", "während"),
    ("waehlt", "wählt"),
    ("wuerde", "würde"),
    ("zaehlen", "zählen"),
    ("zaehlt", "zählt"),
    ("zufaellig", "zufällig"),
    ("zurueck", "zurück"),
    ("uebrig", "übrig"),
    ("ueber", "über"),
    ("haengen", "hängen"),
    ("haengt", "hängt"),
    ("haette", "hätte"),
    ("haelt", "hält"),
    ("laedt", "lädt"),
    ("laesst", "lässt"),
    ("laeuft", "läuft"),
    ("loest", "löst"),
    ("naeher", "näher"),
    ("noetig", "nötig"),
    ("waeren", "wären"),
    ("waere", "wäre"),
    ("grosse", "große"),
    ("Ausreisser", "Ausreißer"),
    ("ausreisser", "ausreißer"),
    ("gross", "groß"),
    ("groesste", "größte"),
    ("groesseres", "größeres"),
    ("groessere", "größere"),
    ("groesser", "größer"),
    ("guenstigsten", "günstigsten"),
    ("guenstiger", "günstiger"),
    ("guenstig", "günstig"),
]


def pretty_german(text: str) -> str:
    protected: list[str] = []

    def protect(match):
        protected.append(match.group(0))
        return f"@@KEEP{len(protected) - 1}@@"

    text = re.sub(r"https?://\S+", protect, text)
    text = re.sub(r"\b[\w./-]*smartgrid_messreihen/[\w./-]+", protect, text)
    text = re.sub(r"\b(?:docs|src)/[\w./-]+", protect, text)
    text = re.sub(r"\b[\w./-]+\.csv\b", protect, text)

    for old, new in sorted(PRETTY_REPLACEMENTS, key=lambda item: len(item[0]), reverse=True):
        text = text.replace(old, new)

    for i, value in enumerate(protected):
        text = text.replace(f"@@KEEP{i}@@", value)
    return text


def prettify_document_text(doc: Document) -> None:
    for para in doc.paragraphs:
        for run in para.runs:
            if run.text:
                run.text = pretty_german(run.text)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        if run.text:
                            run.text = pretty_german(run.text)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


MASTER_ROWS = read_csv(MASTER_INDEX)
AGG_ROWS = read_csv(AGG_CSV)


def fnum(value: str | float | int | None) -> float:
    if value in (None, ""):
        return 0.0
    return float(value)


def fmt_de(value: float, digits: int = 1) -> str:
    return f"{value:.{digits}f}".replace(".", ",")


def million(value: float) -> float:
    return value / 1_000_000.0


def group_rows(rows: list[dict[str, str]], source: str | None = None) -> list[dict[str, str]]:
    if source is None:
        return rows
    return [r for r in rows if r["source_group"] == source]


def aggregate_for(source: str, series: str, controller: str) -> dict[str, float]:
    for r in AGG_ROWS:
        if r["source_group"] == source and r["series"] == series and r["controller"] == controller:
            return {k: fnum(v) for k, v in r.items() if k not in ("source_group", "series", "controller")}
    raise KeyError((source, series, controller))


def aggregate_rows(rows: list[dict[str, str]]) -> dict[str, float]:
    out: dict[str, float] = {}
    for key in [
        "brownout_steps",
        "unserved_energy_mwh",
        "surplus_energy_mwh",
        "co2_kg",
        "peak_deficit_mw",
        "max_frequency_deviation_hz",
        "ticks_outside_freq_dead_band",
        "total_cost_eur",
        "lcoe_eur_per_mwh",
    ]:
        vals = [fnum(r[key]) for r in rows]
        out[key + "_mean"] = sum(vals) / len(vals)
        if len(vals) > 1:
            mean = out[key + "_mean"]
            out[key + "_sd"] = math.sqrt(sum((v - mean) ** 2 for v in vals) / (len(vals) - 1))
        else:
            out[key + "_sd"] = 0.0
    return out


BASELINE_NAIVE = aggregate_for("baseline", "baseline_n15", "naive")
BASELINE_RB = aggregate_for("baseline", "baseline_n15", "rule_based")
CLAUDE_ALL = aggregate_rows(group_rows(MASTER_ROWS, "claude_live"))
CODEX_ALL = aggregate_rows(group_rows(MASTER_ROWS, "codex_operator"))


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
    ]
    for c in candidates:
        if Path(c).exists():
            return ImageFont.truetype(c, size=size)
    return ImageFont.load_default()


def draw_grouped_bars(
    filename: str,
    title: str,
    ylabel: str,
    labels: list[str],
    series: list[tuple[str, list[float], tuple[int, int, int]]],
    value_fmt=lambda x: f"{x:.0f}",
) -> Path:
    w, h = 1400, 850
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    title_font = load_font(32, bold=True)
    axis_font = load_font(21)
    label_font = load_font(18)
    small_font = load_font(16)
    d.text((70, 35), title, fill=(20, 37, 68), font=title_font)
    left, right, top, bottom = 115, 70, 120, 165
    pw, ph = w - left - right, h - top - bottom
    max_val = max(max(vals) for _, vals, _ in series)
    max_val = max_val * 1.18 if max_val > 0 else 1.0
    grid_color = (220, 226, 234)
    for i in range(6):
        y = top + ph - i * ph / 5
        d.line((left, y, w - right, y), fill=grid_color, width=1)
        val = max_val * i / 5
        d.text((25, y - 12), value_fmt(val), fill=(80, 80, 80), font=small_font)
    d.line((left, top, left, top + ph), fill=(70, 70, 70), width=2)
    d.line((left, top + ph, w - right, top + ph), fill=(70, 70, 70), width=2)
    group_w = pw / len(labels)
    bar_w = min(42, group_w / (len(series) + 1))
    for gi, lab in enumerate(labels):
        cx = left + group_w * gi + group_w / 2
        start = cx - (len(series) * bar_w) / 2
        for si, (_, vals, color) in enumerate(series):
            val = vals[gi]
            bh = val / max_val * ph
            x0 = start + si * bar_w
            x1 = x0 + bar_w * 0.78
            y0 = top + ph - bh
            d.rectangle((x0, y0, x1, top + ph), fill=color, outline=(50, 50, 50))
            d.text((x0 - 3, y0 - 22), value_fmt(val), fill=(30, 30, 30), font=small_font)
        tw = d.textlength(lab, font=label_font)
        d.text((cx - tw / 2, top + ph + 18), lab, fill=(30, 30, 30), font=label_font)
    d.text((70, h - 70), ylabel, fill=(60, 60, 60), font=axis_font)
    lx = 930
    ly = 45
    for name, _, color in series:
        d.rectangle((lx, ly, lx + 22, ly + 22), fill=color, outline=(40, 40, 40))
        d.text((lx + 32, ly - 2), name, fill=(30, 30, 30), font=label_font)
        ly += 32
    path = CHART_DIR / filename
    img.save(path)
    return path


def draw_scatter(filename: str) -> Path:
    rows = MASTER_ROWS
    w, h = 1400, 850
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    title_font = load_font(32, bold=True)
    label_font = load_font(19)
    small_font = load_font(16)
    d.text((70, 35), "Brownouts und nicht gelieferte Energie pro Lauf", fill=(20, 37, 68), font=title_font)
    left, right, top, bottom = 115, 80, 115, 120
    pw, ph = w - left - right, h - top - bottom
    max_x = max(fnum(r["brownout_steps"]) for r in rows) * 1.1
    max_y = max(fnum(r["unserved_energy_mwh"]) for r in rows) * 1.1
    for i in range(6):
        x = left + i * pw / 5
        y = top + ph - i * ph / 5
        d.line((x, top, x, top + ph), fill=(226, 230, 236))
        d.line((left, y, left + pw, y), fill=(226, 230, 236))
        d.text((x - 12, top + ph + 12), f"{max_x*i/5:.0f}", fill=(70, 70, 70), font=small_font)
        d.text((30, y - 10), f"{max_y*i/5:.0f}", fill=(70, 70, 70), font=small_font)
    d.line((left, top, left, top + ph), fill=(70, 70, 70), width=2)
    d.line((left, top + ph, left + pw, top + ph), fill=(70, 70, 70), width=2)
    colors = {
        "baseline": (90, 90, 90),
        "claude_live": (199, 50, 50),
        "codex_operator": (39, 120, 84),
    }
    for r in rows:
        x = left + fnum(r["brownout_steps"]) / max_x * pw
        y = top + ph - fnum(r["unserved_energy_mwh"]) / max_y * ph
        color = colors[r["source_group"]]
        d.ellipse((x - 6, y - 6, x + 6, y + 6), fill=color, outline=(30, 30, 30))
    d.text((left + 390, top + ph + 55), "Brownout-Ticks", fill=(50, 50, 50), font=label_font)
    d.text((20, top + 10), "Unserved Energy [MWh]", fill=(50, 50, 50), font=label_font)
    lx, ly = 900, 65
    for lab, color in [("Baselines", colors["baseline"]), ("Claude Live", colors["claude_live"]), ("Codex Operator", colors["codex_operator"])]:
        d.ellipse((lx, ly, lx + 16, ly + 16), fill=color, outline=(30, 30, 30))
        d.text((lx + 26, ly - 3), lab, fill=(30, 30, 30), font=label_font)
        ly += 30
    path = CHART_DIR / filename
    img.save(path)
    return path


def draw_h2_soc(filename: str) -> Path:
    candidates = [
        ("RuleBased", "baseline", "baseline_n15", "rule_based", 42, (45, 100, 185)),
        ("Claude Live", "claude_live", "reihe_01", "claude_subagent", 42, (199, 50, 50)),
        ("Codex R2", "codex_operator", "round_02_codex_r2", "codex_r2", 42, (39, 120, 84)),
    ]
    series = []
    for name, source, ser, ctrl, seed, color in candidates:
        match = [
            r for r in MASTER_ROWS
            if r["source_group"] == source and r["series"] == ser and r["controller"] == ctrl and int(r["seed"]) == seed
        ]
        if not match or not match[0]["csv_path"]:
            continue
        csv_path = ROOT / match[0]["csv_path"]
        vals = []
        with csv_path.open(encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                for key in row:
                    if "h2_speicher" in key.lower() and "soc_mwh" in key.lower():
                        vals.append(float(row[key]))
                        break
        if vals:
            series.append((name, vals, color))
    w, h = 1400, 850
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    title_font = load_font(32, bold=True)
    label_font = load_font(19)
    small_font = load_font(16)
    d.text((70, 35), "H2-Speicherverlauf bei Seed 42", fill=(20, 37, 68), font=title_font)
    left, right, top, bottom = 115, 80, 115, 115
    pw, ph = w - left - right, h - top - bottom
    max_y = 5000
    for i in range(6):
        y = top + ph - i * ph / 5
        d.line((left, y, left + pw, y), fill=(226, 230, 236))
        d.text((35, y - 10), f"{max_y*i/5:.0f}", fill=(70, 70, 70), font=small_font)
    for i in range(0, 25, 4):
        x = left + i / 24 * pw
        d.line((x, top, x, top + ph), fill=(235, 238, 242))
        d.text((x - 8, top + ph + 12), str(i), fill=(70, 70, 70), font=small_font)
    d.line((left, top, left, top + ph), fill=(70, 70, 70), width=2)
    d.line((left, top + ph, left + pw, top + ph), fill=(70, 70, 70), width=2)
    for name, vals, color in series:
        pts = []
        for i, v in enumerate(vals):
            x = left + (i / max(1, len(vals) - 1)) * pw
            y = top + ph - (v / max_y) * ph
            pts.append((x, y))
        if len(pts) > 1:
            d.line(pts, fill=color, width=4)
    lx, ly = 940, 65
    for name, _, color in series:
        d.line((lx, ly + 8, lx + 28, ly + 8), fill=color, width=5)
        d.text((lx + 38, ly - 4), name, fill=(30, 30, 30), font=label_font)
        ly += 32
    d.text((left + 420, top + ph + 55), "Stunde des Tages", fill=(50, 50, 50), font=label_font)
    d.text((25, top + 10), "SoC [MWh]", fill=(50, 50, 50), font=label_font)
    path = CHART_DIR / filename
    img.save(path)
    return path


def make_charts() -> dict[str, Path]:
    labels = ["Naive", "RuleB.", "Claude", "Codex"]
    brownouts = [
        BASELINE_NAIVE["brownout_steps_mean"],
        BASELINE_RB["brownout_steps_mean"],
        CLAUDE_ALL["brownout_steps_mean"],
        CODEX_ALL["brownout_steps_mean"],
    ]
    unserved = [
        BASELINE_NAIVE["unserved_energy_mwh_mean"],
        BASELINE_RB["unserved_energy_mwh_mean"],
        CLAUDE_ALL["unserved_energy_mwh_mean"],
        CODEX_ALL["unserved_energy_mwh_mean"],
    ]
    surplus = [
        BASELINE_NAIVE["surplus_energy_mwh_mean"],
        BASELINE_RB["surplus_energy_mwh_mean"],
        CLAUDE_ALL["surplus_energy_mwh_mean"],
        CODEX_ALL["surplus_energy_mwh_mean"],
    ]
    cost = [
        million(BASELINE_NAIVE["total_cost_eur_mean"]),
        million(BASELINE_RB["total_cost_eur_mean"]),
        million(CLAUDE_ALL["total_cost_eur_mean"]),
        million(CODEX_ALL["total_cost_eur_mean"]),
    ]
    freq = [
        BASELINE_NAIVE["max_frequency_deviation_hz_mean"],
        BASELINE_RB["max_frequency_deviation_hz_mean"],
        CLAUDE_ALL["max_frequency_deviation_hz_mean"],
        CODEX_ALL["max_frequency_deviation_hz_mean"],
    ]
    charts = {
        "brownout_unserved": draw_grouped_bars(
            "aktuell_brownouts_unserved.png",
            "Versorgungssicherheit: Anzahl und Tiefe der Defizite",
            "Brownouts / MWh",
            labels,
            [
                ("Brownouts", brownouts, (70, 120, 190)),
                ("Unserved MWh / 20", [x / 20 for x in unserved], (199, 68, 64)),
            ],
            value_fmt=lambda x: f"{x:.0f}",
        ),
        "surplus_cost": draw_grouped_bars(
            "aktuell_surplus_cost.png",
            "Energieverschwendung und Kosten",
            "MWh / Mio. EUR",
            labels,
            [
                ("Surplus MWh", surplus, (91, 157, 95)),
                ("Kosten Mio. EUR x 50", [x * 50 for x in cost], (118, 90, 160)),
            ],
            value_fmt=lambda x: f"{x:.0f}",
        ),
        "freq": draw_grouped_bars(
            "aktuell_frequenz.png",
            "Maximale Frequenzabweichung",
            "Hz",
            labels,
            [("max |df|", freq, (230, 151, 55))],
            value_fmt=lambda x: f"{x:.2f}",
        ),
        "scatter": draw_scatter("aktuell_scatter_brownouts_unserved.png"),
        "h2": draw_h2_soc("aktuell_h2_soc_seed42.png"),
    }
    return charts


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_text(cell, text: str, bold: bool = False, size: int = 9) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(str(text))
    run.bold = bold
    run.font.name = "Calibri"
    run.font.size = Pt(size)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def add_table(doc: Document, headers: list[str], data: list[list[str]], widths: list[float] | None = None, font_size: int = 8):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for i, h in enumerate(headers):
        set_cell_text(hdr.cells[i], h, bold=True, size=font_size)
        set_cell_shading(hdr.cells[i], "E8EEF5")
        hdr.cells[i].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    for row in data:
        cells = table.add_row().cells
        for i, val in enumerate(row):
            set_cell_text(cells[i], val, size=font_size)
            cells[i].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Inches(width)
    doc.add_paragraph()
    return table


MAIN_SECTIONS: list[tuple[str, list[str]]] = [
    (
        "1. Ziel dieses Teils der Arbeit",
        [
            "In diesem Teil der Seminararbeit wird die Simulationssoftware erklaert und mit den Messreihen ausgewertet. Es geht nicht darum, ein echtes Stromnetz bis in jede technische Einzelheit nachzubauen. Das Ziel ist ein kontrolliertes physikalisches Modell, mit dem man verschiedene Steuerungsweisen fair miteinander vergleichen kann. Alle Strategien bekommen dieselben Wetterdaten, dieselben Lasten und dieselben Speicher. Geaendert wird nur, wie die Anlage bedient wird.",
            "Die Leitfrage lautet: Kann eine KI-Steuerung ein Stromsystem mit 100 Prozent erneuerbarer Energie sicherer betreiben als einfache Regeln? Diese Frage ist interessant, weil erneuerbare Energie nicht jederzeit gleich stark verfuegbar ist. Photovoltaik liefert nachts nichts und mittags sehr viel. Wind kann stark schwanken. Gleichzeitig erwarten Verbraucher, dass Strom immer da ist. Das Stromsystem braucht deshalb Speicher und eine gute Steuerung.",
            "Fuer die Auswertung werden mehrere Steuerungen verglichen. Es gibt eine naive Steuerung, eine regelbasierte Steuerung, Claude-Live-Laeufe und Codex-Operator-Laeufe. Die Claude- und Codex-Laeufe sind keine eingebauten Kraftwerksmodelle, sondern Bediener des Simulators. Sie lesen den Netzzustand und entscheiden dann, welche Leistung Speicher, Wasserstoff-Gasturbine, Elektrolyseur oder andere flexible Komponenten bekommen sollen.",
        ],
    ),
    (
        "2. Warum ueberhaupt eine Simulation?",
        [
            "Ein echtes Stromnetz kann man fuer eine Seminararbeit nicht einfach ausprobieren. Man kann nicht absichtlich Speicher leeren, Kraftwerke falsch steuern und dann schauen, ob ein Stadtgebiet einen Brownout bekommt. Eine Simulation ist deshalb ein sicherer Ersatz. Sie erlaubt Experimente, die in der Realitaet zu teuer, zu gefaehrlich oder schlicht nicht erlaubt waeren.",
            "Der Vorteil einer Simulation ist die Wiederholbarkeit. Wenn derselbe Seed verwendet wird, sind Wetter, Lasten und Anfangszustaende gleich. Dadurch kann man eine Strategie mit einer anderen vergleichen, ohne dass schlechtes Wetter oder Zufall das Ergebnis verfalschen. Besonders wichtig ist das beim Vergleich mit KI, weil man sonst nicht weiss, ob die KI wirklich besser war oder nur gluecklichere Wetterbedingungen hatte.",
            "Die Simulation bildet einen vereinfachten Sammelknoten ab. Das bedeutet: Alle Erzeuger, Speicher und Verbraucher haengen gedanklich an einem gemeinsamen Punkt. Leitungsverluste, Transformatoren und lokale Netzengpaesse werden nicht modelliert. Diese Vereinfachung ist fuer die Fragestellung sinnvoll, weil zuerst untersucht werden soll, ob die Energiebilanz und die Steuerung ueberhaupt funktionieren.",
            "In der Physik ist ein Modell immer eine Vereinfachung. Entscheidend ist nicht, ob es alles enthaelt, sondern ob es die wichtigen Zusammenhaenge fuer die Fragestellung enthaelt. Fuer diese Arbeit sind besonders wichtig: Leistung, Energie, Speicherfuellstand, Wetterabhaengigkeit, Lastprofil, Bilanzfehler und Frequenzabweichung. Genau diese Groessen werden im Simulator berechnet.",
        ],
    ),
    (
        "3. Grundidee des Smart-Grid-Modells",
        [
            "Das simulierte System stellt eine mittelgrosse Stadt dar. Die Stadt hat Wohnlasten, Gewerbelasten und Industrielasten. Diese Verbraucher entnehmen Strom aus dem Netz. Auf der Erzeugungsseite gibt es Photovoltaik, Windkraft, Laufwasser, Biomasse, Geothermie und eine Wasserstoff-Gasturbine. Dazu kommen Speicher: Batterie, Pumpspeicher und ein saisonaler Wasserstoffspeicher.",
            "Das Modell ist zu 100 Prozent erneuerbar gedacht. Das bedeutet nicht, dass jede Kilowattstunde direkt aus Sonne oder Wind kommt. Es bedeutet, dass auch das Backup ueber Wasserstoff gedacht ist, der vorher mit erneuerbarem Strom erzeugt wurde. Der Elektrolyseur nimmt Strom auf und laedt den Wasserstoffspeicher. Die Wasserstoff-Gasturbine entnimmt spaeter Energie aus diesem Speicher und macht daraus wieder Strom.",
            "Ein wichtiger Punkt ist die Vorzeichenregel. Erzeuger haben positive Leistung, weil sie Strom ins Netz einspeisen. Lasten haben negative Leistung, weil sie Strom aus dem Netz ziehen. Speicher koennen beides sein: Beim Entladen sind sie positiv, beim Laden negativ. Dadurch kann die Software in jedem Zeitschritt alle Leistungen einfach addieren.",
            "Wenn die Summe aller Leistungen positiv ist, entsteht Ueberschuss. Dann wurde mehr erzeugt als gerade verbraucht oder gespeichert werden kann. Wenn die Summe negativ ist, fehlt Leistung. Dann entsteht ein Defizit. Solche Defizit-Zeitschritte nennt die Arbeit Brownout-Ticks. Sie sind die wichtigste Messgroesse fuer Versorgungssicherheit.",
        ],
    ),
    (
        "4. Der Ablauf eines Simulationsschritts",
        [
            "Die Simulation laeuft in Zeitschritten von 15 Minuten. Ein kompletter Tag hat deshalb 96 Schritte. In jedem Schritt wird zuerst das Wetter fuer die aktuelle Zeit bestimmt. Dazu gehoeren Globalstrahlung, Windgeschwindigkeit und Temperatur. Danach berechnet jede Komponente ihre Leistung fuer genau diesen Schritt.",
            "Bei der Photovoltaik haengt die Leistung von der Einstrahlung und der Modulflaeche ab. Bei Windkraft haengt sie stark von der Windgeschwindigkeit ab, ungefaehr mit der dritten Potenz. Das bedeutet: doppelte Windgeschwindigkeit kann viel mehr als doppelte Leistung bedeuten, solange die Anlage noch nicht bei ihrer Nennleistung angekommen ist.",
            "Nachdem alle Komponenten ihre Leistung geliefert haben, berechnet die Engine die Summe. Aus dieser Summe entstehen Energie, Defizit oder Ueberschuss. Leistung ist dabei eine momentane Groesse in Megawatt. Energie ist Leistung mal Zeit. Wenn zum Beispiel 100 MW eine Viertelstunde lang fehlen, fehlen 25 MWh Energie.",
            "Die Begriffe Leistung und Energie sind hier normale physikalische Grundlagen. Als externe Einordnung ist dazu Q3 im Detailquellenblatt angegeben. Die konkreten Werte des Simulators stammen aber aus dem eigenen Modell und nicht aus Q3.",
            "Am Ende des Schritts wird ein Datensatz gespeichert. Er enthaelt Wetter, Leistungen, Speicherfuellstaende, CO2, Bilanz und Frequenz. Diese Datensaetze bilden spaeter die CSV-Dateien der Messreihen. Der naechste Steuerungsbefehl arbeitet dann auf dem neuen Zustand weiter.",
        ],
    ),
    (
        "5. Die wichtigsten Komponenten",
        [
            "Die Wohnlast hat im Modell morgens und abends eine Spitze. Das passt zu typischem Verhalten: morgens stehen Menschen auf, abends wird gekocht, gewaschen und geheizt. Gewerbe hat eher tagsueber einen Block, weil Geschaefte und Betriebe dann offen sind. Industrie ist fast konstant, nur nachts etwas niedriger.",
            "Photovoltaik ist im Modell nicht steuerbar, ausser dass sie abgeregelt werden kann. Abregelung bedeutet: Ein Teil der moeglichen Erzeugung wird bewusst nicht genutzt. Das ist schade, kann aber noetig sein, wenn Speicher voll sind und sonst zu viel Strom im Netz waere. Windkraft ist aehnlich: Sie folgt dem Wetter und kann nur begrenzt durch Curtailment reduziert werden.",
            "Biomasse und Geothermie sind erneuerbar und regelbar. Sie koennen einen Sollwert bekommen, haben aber technische Grenzen. Die Wasserstoff-Gasturbine ist das schnelle Backup. Sie kann in Defiziten viel Leistung bereitstellen. Seit der Ueberarbeitung ist sie aber nicht mehr unbegrenzt: Sie verbraucht Wasserstoff aus dem saisonalen Speicher.",
            "Die Batterie ist ein schneller Kurzzeitspeicher. Der Pumpspeicher ist groesser und eignet sich fuer mehrere Stunden. Der Wasserstoffspeicher ist sehr gross, aber ineffizient. Er ist eher fuer laengere Flauten gedacht. Diese drei Speicher haben deshalb verschiedene Aufgaben und duerfen nicht gleich behandelt werden.",
            "Die allgemeine Speicherlogik wird durch externe Hintergrundquellen gestuetzt: Q4 fuer Speicher im Solarsystem, Q5 fuer Pumpspeicher und Q6 fuer Elektrolyseure. Die Groessen der Speicher und ihre Wirkungsgrade sind aber Modellannahmen der eigenen Simulation.",
            "Sektorkopplung macht das Modell interessanter. Waermepumpen koennen Waerme teilweise verschieben, Elektroautos koennen laden oder ins Netz zurueckspeisen, und der Elektrolyseur kann Ueberschussstrom in Wasserstoff umwandeln. Diese Verbraucher sind nicht nur Lasten, sondern auch Stellgroessen fuer die Steuerung.",
        ],
    ),
    (
        "6. Wetter, Seeds und Reproduzierbarkeit",
        [
            "Ein Seed ist eine Zahl, aus der die Wetterzeitreihe erzeugt wird. Wenn man denselben Seed wieder benutzt, entstehen dieselben Wetterwerte. Das ist fuer die wissenschaftliche Auswertung wichtig. Sonst koennte eine Strategie nur deshalb besser aussehen, weil sie zufaellig mehr Wind hatte.",
            "Die Wetterfunktionen wurden so angepasst, dass eine Wetterabfrage den spaeteren Verlauf nicht veraendert. Das klingt technisch, ist aber wichtig: Ein Controller darf fuer eine Vorhersage das Wetter abfragen, ohne dadurch das echte Wetter im naechsten Tick zu verschieben. Damit sind Live-Steuerung, automatische Controller und Auswertung fairer vergleichbar.",
            "Die 15 Haupt-Seeds sind 3, 5, 7, 13, 17, 19, 23, 31, 41, 42, 55, 67, 73, 88 und 99. Diese Seeds bilden die Grundlage fuer die Baselines, die Claude-Live-Laeufe und die Codex-Laeufe. Die Baselines laufen fuer jeden Seed mit denselben Anfangsbedingungen.",
            "Trotz Seeds bleibt das Wetter synthetisch. Es ist also kein echter DWD-Datensatz. Fuer die Seminararbeit reicht das, weil es um den Vergleich der Steuerungen geht. Fuer eine echte Netzplanung muesste man spaeter reale Wetter- und Lastdaten verwenden.",
        ],
    ),
    (
        "7. Messgroessen: Was wird bewertet?",
        [
            "Die wichtigste Messgroesse ist nicht einfach die Anzahl der Brownouts. Ein Brownout-Tick sagt nur, dass in diesem Zeitschritt Leistung gefehlt hat. Er sagt aber noch nicht, wie viel Leistung gefehlt hat. Deshalb wird zusaetzlich die unversorgte Energie in MWh gemessen. Diese Groesse ist oft aussagekraeftiger.",
            "Ein Beispiel macht das klar: Eine Strategie kann zehn kleine Defizite haben, eine andere nur drei sehr grosse Defizite. Rein nach Brownout-Anzahl waere die zweite Strategie besser. Fuer die Stadt waere sie aber schlechter, wenn insgesamt viel mehr Energie nicht geliefert wurde. Deshalb muessen Brownout-Ticks und unserved energy zusammen betrachtet werden.",
            "Surplus Energy misst, wie viel Energie uebrig bleibt. Ueberschuss ist nicht automatisch schlimm, aber grosse Ueberschuesse bedeuten, dass Speicher oder flexible Lasten schlecht genutzt wurden. In einem erneuerbaren System ist es wichtig, Mittagsspitzen nicht einfach wegzuwerfen, sondern Speicher zu laden oder Wasserstoff zu erzeugen.",
            "Die Frequenzabweichung ist ein physikalischer Stabilitaetsindikator. In echten Stromnetzen muss Erzeugung und Verbrauch fast gleichzeitig ausgeglichen sein. Wenn zu viel Leistung fehlt, sinkt die Frequenz. Wenn zu viel Leistung da ist, steigt sie. Das Modell nutzt eine vereinfachte Droop-Naehung, um diese Wirkung sichtbar zu machen.",
            "Die Wirtschaftlichkeit wird ueber Brennstoffkosten, CO2-Kosten, Speicherkosten, Markterloese und vor allem Value of Lost Load berechnet. Value of Lost Load ist der angenommene Schaden, wenn Strom nicht geliefert wird. Dadurch werden Defizite wirtschaftlich stark bestraft, was realistisch ist: Ein Stromausfall ist teuer.",
            "Fuer die allgemeine Frequenzeinordnung wird Q7 angegeben. Fuer den Begriff Value of Lost Load wird Q8 angegeben. Beide Quellen liefern Hintergrund, waehrend die konkreten Frequenz- und Kostenwerte aus den Messreihen Q2 stammen.",
        ],
    ),
    (
        "8. Die naive Steuerung",
        [
            "Die naive Steuerung ist absichtlich einfach. Sie setzt feste Sollwerte und reagiert danach kaum auf Wetter oder Last. Biomasse und Geothermie laufen hoch, die Wasserstoff-Gasturbine arbeitet als konstantes Backup, Speicher bleiben weitgehend passiv. Diese Strategie ist kein ernsthafter Netzbetrieb, sondern eine untere Vergleichsgrenze.",
            "Der Vorteil der naiven Steuerung ist ihre Einfachheit. Man kann gut sehen, was passiert, wenn ein System mit vielen erneuerbaren Komponenten nicht aktiv gesteuert wird. Sie verschwendet viel Energie, weil Speicher und flexible Lasten nicht klug genutzt werden. Gleichzeitig hat sie tiefe Defizite, wenn die feste Leistung nicht reicht.",
            "In den Messreihen hat Naive im Mittel 59,87 Brownout-Ticks, aber sehr hohe unversorgte Energie von 1248,30 MWh. Das zeigt den Unterschied zwischen Anzahl und Tiefe der Ausfaelle. Die Brownout-Anzahl ist nicht extrem hoch im Vergleich zu RuleBased, aber die Defizite sind viel staerker.",
            "Auch wirtschaftlich ist Naive klar schlecht. Die mittleren Tageskosten liegen bei etwa 8,93 Millionen Euro. Der Hauptgrund ist nicht CO2, sondern nicht gelieferte Energie. Wenn Verbraucher nicht versorgt werden, wird das ueber den Value of Lost Load sehr teuer bewertet.",
        ],
    ),
    (
        "9. Die regelbasierte Steuerung",
        [
            "Die regelbasierte Steuerung ist die wichtigste klassische Vergleichsstrategie. Sie arbeitet nicht mit Sprache und nicht mit freier Planung, sondern mit festen Regeln. Bei Defizit werden zuerst effiziente Speicher genutzt, danach Vehicle-to-Grid und Wasserstoff. Bei Ueberschuss werden zuerst Speicher geladen, dann flexible Lasten und am Ende wird abgeregelt.",
            "Diese Art von Steuerung ist gut nachvollziehbar. Man kann in den Regeln nachlesen, warum etwas passiert. Das ist ein Vorteil gegenueber KI-Modellen, deren Entscheidung oft schwerer zu erklaeren ist. Fuer ein sicherheitskritisches System wie ein Stromnetz ist Nachvollziehbarkeit sehr wichtig.",
            "In den Messreihen hat RuleBased im Mittel 63,73 Brownout-Ticks. Das ist mehr als Naive und mehr als Codex. Trotzdem ist RuleBased bei der unversorgten Energie deutlich besser: nur 233,25 MWh im Mittel. Die Defizite sind also haeufiger, aber viel kleiner.",
            "RuleBased ist auch bei Frequenz und Kosten stark. Die maximale Frequenzabweichung liegt im Mittel bei 0,366 Hz, deutlich besser als Naive und Claude. Die Tageskosten liegen bei etwa 1,82 Millionen Euro. Damit ist RuleBased insgesamt die robusteste klassische Strategie im Datensatz.",
        ],
    ),
    (
        "10. Claude als Live-Steuerung",
        [
            "Claude Live bedeutet hier: Claude-Subagents bedienten die Simulation ueber die Kommandozeile. Der Ablauf war damit grundsaetzlich derselbe Bedienweg wie bei Codex: Zustand lesen, Entscheidung ableiten, CLI-Befehle setzen und danach den naechsten Tick ausfuehren. Es war also kein fest eingebauter Controller im Simulator, sondern eine agentische Bedienung der vorhandenen CLI.",
            "Claude hat eine interessante Staerke: Die Anzahl der Brownout-Ticks ist niedriger als bei RuleBased. Ueber alle 15 Claude-Laeufe liegt der Mittelwert bei etwa 55,47 Brownout-Ticks. Rein nach dieser einen Zahl sieht Claude also besser aus.",
            "Das Problem ist aber die Tiefe der Defizite. Claude verursacht im Mittel rund 1028,90 MWh unversorgte Energie. Das ist deutlich schlechter als RuleBased. Dazu kommen hohe Ueberschuesse und hohe Kosten. Claude vermeidet also einige Brownout-Zeitschritte, erzeugt dafuer aber groessere einzelne Probleme.",
            "Der wichtigste beobachtete Fehler ist der Umgang mit dem Wasserstoffspeicher. Claude nutzt den Wasserstoff frueh und stark, statt ihn fuer spaetere Lastspitzen zu reservieren. Wenn der Speicher leer ist, kann die H2-Gasturbine nicht mehr helfen. Das fuehrt besonders spaeter am Tag zu tiefen Defiziten.",
            "Fuer die Forschungsfrage ist das spannend. Das Sprachmodell kann Situationen sprachlich gut beschreiben und reagiert teilweise sinnvoll. Es plant aber den Tagesenergiehaushalt nicht zuverlaessig genug. Bei einem Stromnetz reicht kurzfristiges Reagieren nicht aus; Speicher muessen ueber viele Stunden geplant werden.",
        ],
    ),
    (
        "11. Codex als Operator der Simulationssoftware",
        [
            "Die Codex-Messreihen sind ein weiterer Vergleich. Auch hier wurde die Simulation ueber die CLI bedient: Zustand auslesen, Sollwerte setzen und die Simulation weiterlaufen lassen. Der Unterschied zu den Claude-Laeufen liegt nicht im grundsaetzlichen Bedienweg, sondern darin, dass die Claude-Reihen mit Claude-Subagents und die Codex-Reihen mit Codex als Operator ausgefuehrt wurden.",
            "Wichtig ist: Codex ist hier nicht direkt ein eingebauter optimierender Controller im eigentlichen Softwarepaket. Es ist eher ein Bediener, der aus dem vorhandenen Zustand eine Strategie ableitet. Damit ist es vergleichbarer mit einer Person oder einem Agenten, der die CLI benutzt.",
            "Es wurden drei Codex-Durchgaenge gemacht. Sie unterscheiden sich leicht in der Bedienstrategie, zum Beispiel darin, wie vorsichtig Wasserstoff zurueckgehalten wird oder wie stark Vehicle-to-Grid genutzt wird. Jeder Durchgang umfasst 15 Seeds mit je 96 Ticks.",
            "Die Codex-Ergebnisse liegen deutlich naeher an RuleBased als die Claude-Ergebnisse. Codex hat im Mittel etwa 56 bis 57 Brownout-Ticks und nur etwa 300 MWh unversorgte Energie. Das ist schlechter als RuleBased, aber viel besser als Claude Live und Naive.",
            "Auffaellig ist, dass alle drei Codex-Durchgaenge sehr aehnliche Ergebnisse liefern. Kleine Aenderungen an der Strategie veraendern die Resultate nur wenig. Das spricht dafuer, dass diese Bedienlogik stabil ist, aber an eine Grenze kommt: Sie reduziert Brownout-Anzahl und Surplus, erreicht aber nicht die geringe unversorgte Energie von RuleBased.",
        ],
    ),
    (
        "12. Vergleich der Steuerungsweisen",
        [
            "Der faire Vergleich muss mehrere Zielgroessen gleichzeitig betrachten. Wenn man nur Brownout-Ticks zaehlt, schneiden Claude und Codex besser ab als RuleBased. Wenn man aber die unversorgte Energie, Frequenz und Kosten betrachtet, dreht sich das Bild. Dann ist RuleBased deutlich besser.",
            "RuleBased erzeugt relativ viele kleine Defizite. Claude erzeugt weniger Defizit-Zeitschritte, aber diese Defizite sind viel tiefer. Codex liegt dazwischen: weniger Brownout-Ticks als RuleBased, aber mehr unversorgte Energie. Naive ist in fast allen wichtigen Punkten deutlich schlechter.",
            "Fuer ein Stromnetz ist die unversorgte Energie wichtiger als die reine Anzahl der betroffenen Ticks. Ein kurzer kleiner Fehler ist weniger schlimm als ein grosser Leistungseinbruch. Deshalb darf man die Hypothese nicht nur anhand der Brownout-Anzahl bewerten.",
            "Bei den Kosten zeigt sich dasselbe. RuleBased ist mit rund 1,82 Millionen Euro pro Tag am guenstigsten. Codex liegt bei etwa 2,29 bis 2,31 Millionen Euro. Claude liegt bei etwa 7 bis 8 Millionen Euro, Naive bei fast 9 Millionen Euro. Die Kosten folgen vor allem der unversorgten Energie.",
            "Bei der Energieverschwendung ist Codex sogar sehr gut. Codex hat nur etwa 10 MWh Surplus, RuleBased etwa 21 MWh, Claude mehrere hundert MWh und Naive etwa 400 MWh. Das zeigt: Codex nutzt Ueberschuesse gut, aber die Defizitdeckung bleibt nicht so gut wie bei RuleBased.",
        ],
    ),
    (
        "13. Warum KI hier nicht automatisch besser ist",
        [
            "Ein Sprachmodell kann Zusammenhaenge gut formulieren, aber ein Stromnetz ist eine Bilanzaufgabe. Es reicht nicht, im Moment sinnvoll zu reagieren. Man muss auch wissen, wie viel Energie spaeter noch gebraucht wird. Genau das ist bei Speichern entscheidend.",
            "Der Wasserstoffspeicher ist dafuer das beste Beispiel. Er ist gross, aber ineffizient und wertvoll. Wenn man ihn morgens zu stark entlaedt, fehlt er abends. Ein Mensch kann das nach dem Lauf leicht erkennen. Die Schwierigkeit liegt darin, diese Erkenntnis waehrend des Laufs konsequent in Zahlen umzusetzen.",
            "RuleBased macht keine kluge Sprache, aber es hat feste Grenzen und Reihenfolgen. Dadurch trifft es oft langweilige, aber stabile Entscheidungen. Das ist in einem technischen System ein Vorteil. Eine KI-Strategie muesste diese Stabilitaet mit besserer Vorausplanung verbinden.",
            "Die Ergebnisse sprechen daher nicht gegen KI allgemein. Sie zeigen eher, dass eine reine LLM-Steuerung ohne mathematischen Planer riskant ist. Ein besserer Ansatz waere eine Kombination: Ein Optimierer plant Speicherbudgets fuer den Tag, und ein Sprachmodell erklaert, prueft oder passt die Strategie an.",
        ],
    ),
    (
        "14. Physikalischer Hintergrund: Leistung, Energie und Bilanz",
        [
            "Die wichtigste physikalische Groesse im Modell ist die Leistung. Leistung beschreibt, wie schnell Energie umgesetzt wird. Im Simulator wird sie in Megawatt angegeben. Eine Photovoltaikanlage mit 100 MW Leistung liefert in einem Moment 100 MW, wenn die Wetterbedingungen dafuer ausreichen. Eine Last von 100 MW entnimmt im selben Moment 100 MW.",
            "Energie entsteht, wenn Leistung ueber eine Zeit wirkt. Weil ein Zeitschritt 15 Minuten dauert, entspricht ein Schritt einem Viertel einer Stunde. Fehlen also 100 MW ueber einen Schritt, dann fehlen 25 MWh. Diese Umrechnung ist wichtig, weil Brownout-Ticks nur die Anzahl der fehlerhaften Schritte zaehlen, waehrend unserved energy die fehlende Energiemenge berechnet.",
            "Die Bilanz ist in jedem Zeitschritt die Summe aus Erzeugung, Verbrauch und Speicherleistung. Ist die Bilanz null, passt alles genau zusammen. Ist sie positiv, gibt es Ueberschuss. Ist sie negativ, fehlt Leistung. Diese einfache Rechnung ist der Kern des Modells. Viele spaetere Kennzahlen entstehen direkt aus dieser Bilanz.",
            "Ein echtes Stromnetz muss diese Bilanz sehr genau einhalten. Schon kleine Abweichungen wirken sich auf die Frequenz aus. Die Simulation bildet das vereinfacht ab, damit man sieht, wann eine Steuerung das System aus dem Gleichgewicht bringt. Die Frequenz ist deshalb keine vollstaendige Netzsimulation, aber ein nuetzlicher Hinweis auf Stabilitaet.",
            "Fuer die Auswertung ist wichtig, dass Leistung und Energie nicht verwechselt werden. Eine hohe Leistungsspitze kann kurz sein und dadurch wenig Energie betreffen. Ein kleiner Fehler kann lange dauern und dadurch viel Energie verursachen. Deshalb werden im Ergebnisteil immer mehrere Groessen gemeinsam betrachtet.",
        ],
    ),
    (
        "15. Speicher als zentrale Physik des Modells",
        [
            "Speicher sind im Modell nicht nur Zusatzbauteile, sondern der zentrale Grund, warum Steuerung ueberhaupt schwierig wird. Sonne und Wind liefern nicht nach Bedarf. Verbraucher wollen aber Strom genau dann, wenn sie ihn brauchen. Speicher verschieben Energie von einem Zeitpunkt zu einem anderen Zeitpunkt.",
            "Die Batterie ist schnell und relativ effizient. Sie eignet sich dafuer, kurze Defizite oder Ueberschuesse auszugleichen. Man kann sie mit einem kleinen Pufferspeicher vergleichen, der schnell reagiert, aber nicht fuer lange Dunkelflauten gedacht ist. Wenn eine Steuerung die Batterie zu frueh leert, fehlt genau dieser schnelle Puffer spaeter.",
            "Der Pumpspeicher ist groesser und traeger. Er kann mehrere Stunden helfen und ist im Modell eine Art mittlerer Energiespeicher. Er ist besonders nuetzlich, wenn tagsueber viel erneuerbare Energie vorhanden ist und abends die Last steigt. Dann kann tagsueber gepumpt und spaeter wieder Strom erzeugt werden.",
            "Der Wasserstoffspeicher hat eine andere Rolle. Er ist sehr gross, aber der Weg ueber Elektrolyseur, Speicher und Gasturbine ist deutlich ineffizienter als eine direkte Speicherung in der Batterie. Deshalb sollte Wasserstoff nicht fuer jede kleine Schwankung verwendet werden. Er ist eher eine Reserve fuer schwere Defizite.",
            "Genau hier zeigt sich der Unterschied zwischen einer einfachen Reaktion und einer guten Strategie. Eine schlechte Strategie sieht ein Defizit und schaltet sofort viel Wasserstoffleistung ein. Eine bessere Strategie fragt zusaetzlich, ob spaeter noch ein groesseres Defizit kommen koennte. In einem erneuerbaren Netz ist diese Voraussicht entscheidend.",
        ],
    ),
    (
        "16. Wie ein Controller entscheiden muss",
        [
            "Ein Controller bekommt in jedem Schritt einen Zustand. Dazu gehoeren unter anderem Wetter, Last, Erzeugung, Speicherfuellstaende, Frequenz und bisherige Defizite. Aus diesen Informationen muss er Sollwerte fuer steuerbare Komponenten bilden. Dazu gehoeren zum Beispiel Batterie, Pumpspeicher, Elektrolyseur, H2-Gasturbine, Biomasse und flexible Verbraucher.",
            "Bei Ueberschuss ist die Entscheidung scheinbar einfach: Speicher laden. In Wirklichkeit muss der Controller aber entscheiden, welcher Speicher zuerst geladen wird. Eine volle Batterie kann abends wichtig sein. Wasserstoff ist langsamer und ineffizienter, kann aber viel Energie aufnehmen. Flexible Lasten koennen Ueberschuss nutzen, duerfen aber nicht spaeter ein Defizit verursachen.",
            "Bei Defizit ist die Entscheidung noch schwieriger. Der Controller kann schnelle Speicher entladen, Verbraucher verschieben, Vehicle-to-Grid nutzen oder Wasserstoff verstromen. Jede dieser Entscheidungen veraendert den spaeteren Zustand. Wer jetzt zu viel entlaedt, hat spaeter weniger Reserve. Wer jetzt zu wenig entlaedt, erzeugt sofort unversorgte Energie.",
            "Die regelbasierte Steuerung loest dieses Problem mit festen Prioritaeten. Das ist nicht perfekt, aber nachvollziehbar. Sie behandelt nicht jeden Zeitpunkt als neues Einzelproblem, sondern arbeitet nach einer Ordnung. Dadurch bleiben Speicherrollen erkennbar: kurze Speicher fuer kurze Fehler, Wasserstoff fuer groessere und spaetere Engpaesse.",
            "Eine KI-Steuerung muesste im Idealfall zusaetzlich aus Text, Erfahrung und Prognose lernen. In den Messreihen zeigt sich aber, dass Sprache allein nicht reicht. Die Entscheidungen muessen zahlenmaessig zur Energiebilanz passen. Ohne klare Speicherbudgets entsteht schnell eine Strategie, die im Moment plausibel wirkt, aber spaeter Energieprobleme erzeugt.",
        ],
    ),
    (
        "17. Vergleich der KI-Modelle im Detail",
        [
            "Claude Live und Codex Operator werden in der Arbeit beide als KI-nahe CLI-Bedienweisen betrachtet, aber sie sind nicht identisch. Claude Live war eine Messreihe mit Claude-Subagents, die den Zustand interpretierten, Entscheidungen formulierten und dann Befehle an die Simulation gaben. Dadurch sieht man gut, wie ein Sprachmodell mit dem System praktisch umgeht.",
            "Codex Operator war ebenfalls eine CLI-Bedienung, aber staerker auf die systematische Wiederholung der Messreihe ausgerichtet. Die Laeufe wurden ueber alle Seeds und drei Durchgaenge reproduzierbar ausgefuehrt. Codex hat dadurch weniger wie ein freies Gespraech und mehr wie ein technischer Operator gearbeitet. Das erklaert, warum die Ergebnisse stabiler und naeher an RuleBased liegen.",
            "Der wichtigste Unterschied liegt in der Tiefe der Defizite. Claude hat zwar wenige Brownout-Ticks, aber grosse Energiemengen nicht versorgt. Codex hat ebenfalls relativ wenige Brownout-Ticks, aber viel kleinere Defizite als Claude. RuleBased hat mehr Brownout-Ticks, aber die geringste unversorgte Energie unter den relevanten Strategien.",
            "Man kann daraus lernen, dass eine KI nicht nur danach bewertet werden darf, ob sie einzelne Alarme verhindert. Entscheidend ist, wie gross der Schaden ist, wenn ein Alarm doch entsteht. Fuer ein Stromsystem ist ein tiefer Engpass schlimmer als mehrere kleine Korrekturen. Genau das macht die unserved-energy-Kennzahl sichtbar.",
            "Die KI-Modelle unterscheiden sich also nicht nur in ihrer Intelligenz, sondern auch in der Art, wie sie benutzt wurden. Claude Live zeigt die Moeglichkeiten und Risiken eines sprachlichen Controllers. Codex Operator zeigt, dass strukturierte Bedienung deutlich besser sein kann. Beide bleiben aber hinter einer einfachen, klar programmierten Regelstrategie zurueck, wenn Versorgungssicherheit das Hauptziel ist.",
        ],
    ),
    (
        "18. Streuung der Seeds und Fairness der Messreihe",
        [
            "Eine einzelne Simulation waere fuer diese Arbeit zu wenig. Ein Seed kann zufaellig besonders guenstig oder besonders unguenstig sein. Deshalb wurden 15 Seeds verwendet. Jeder Controller musste dieselben Seeds durchlaufen. So kann man Mittelwerte bilden und erkennt, ob ein Ergebnis nur ein Zufall war.",
            "Die Seeds erzeugen unterschiedliche Wetterverlaeufe. Manche Tage haben mehr Wind, andere mehr Photovoltaik oder unguenstige Kombinationen. Dadurch wird die Steuerung in verschiedenen Situationen getestet. Ein guter Controller sollte nicht nur bei einem einfachen Tag funktionieren, sondern auch bei schwierigeren Last- und Wetterlagen.",
            "Die Streuung ist besonders bei KI-Laeufen wichtig. Ein Sprachmodell kann bei einem Lauf eine gute Entscheidung treffen und beim naechsten Lauf anders reagieren. Wenn man nur einen erfolgreichen Lauf zeigen wuerde, waere das wissenschaftlich schwach. Durch die Wiederholung ueber viele Seeds wird sichtbar, ob die Strategie stabil ist.",
            "Die Codex-Reihen enthalten sogar drei komplette Durchgaenge mit jeweils 15 Seeds. Das ist hilfreich, weil man dadurch nicht nur verschiedene Wetterlagen, sondern auch verschiedene Bedienvarianten vergleichen kann. Wenn alle drei Durchgaenge aehnlich ausfallen, spricht das fuer eine robuste Beobachtung.",
            "Fair ist der Vergleich nur, wenn der Simulator selbst deterministisch arbeitet. Deshalb war es wichtig, die Wetterabfragen idempotent zu machen und den CLI-Seed auch wirklich auf das Wetter anzuwenden. Erst dadurch bedeuten gleiche Seeds wirklich gleiche Bedingungen. Ohne diese Korrektur waere der Vergleich weniger belastbar gewesen.",
        ],
    ),
    (
        "19. Was die Korrekturen am Modell verbessert haben",
        [
            "Vor der endgueltigen Auswertung wurden mehrere technische Fehler im Modell ueberprueft und korrigiert. Das ist fuer eine Seminararbeit wichtig, weil die Messwerte nur dann sinnvoll sind, wenn das Modell logisch stimmt. Besonders kritisch waren Reproduzierbarkeit, Wasserstoffkopplung und die wirtschaftliche Auswertung.",
            "Die Wetterabfragen durften keinen Zufallszustand verbrauchen. Wenn eine Prognoseabfrage das spaetere Wetter veraendert, haette ein Controller allein durch Nachfragen andere Bedingungen erzeugt. Das waere wissenschaftlich unfair. Nach der Korrektur haengt das Wetter nur noch von Seed und Zeitpunkt ab.",
            "Der CLI-Seed musste auch den Wetter-Seed setzen. Sonst haette ein Lauf zwar im Grid einen anderen Seed angezeigt, aber trotzdem dasselbe Wetter wie vorher genutzt. Das waere Scheindeterminismus gewesen. Jetzt passen Grid-Seed und Wetter-Seed zusammen.",
            "Die H2-Gasturbine musste den Wasserstoffspeicher wirklich entladen. Ohne diese Kopplung haette sie unbegrenzt Energie liefern koennen. Das waere physikalisch falsch und fuer ein 100 Prozent erneuerbares geschlossenes System unbrauchbar. Die Korrektur macht Wasserstoff zu einer echten begrenzten Ressource.",
            "Auch die wirtschaftliche Rechnung wurde vorsichtiger behandelt. Speicherentladung darf nicht einfach wie neue Markterzeugung doppelt als Erlos gezaehlt werden. Fuer die Rentabilitaet sind Markterloese wichtig, aber sie muessen sauber von Defizitkosten, Speicherbetrieb und echter Einspeisung getrennt werden. Dadurch sind die Kostenvergleiche glaubwuerdiger.",
        ],
    ),
    (
        "20. Interpretation der wichtigsten Ergebnisbilder",
        [
            "Die Diagramme im naechsten Teil zeigen nicht neue Daten, sondern dieselben Messreihen in einer uebersichtlichen Form. Sie sollen dem Leser helfen, die Unterschiede schneller zu erkennen. Besonders wichtig ist der Vergleich zwischen Brownout-Anzahl und unversorgter Energie.",
            "Wenn eine Saeule bei Brownouts niedrig ist, klingt das zuerst gut. Erst die zweite Saeule zeigt, ob die Defizite klein oder gross waren. Das ist der Grund, warum Claude im ersten Blick besser wirkt, im zweiten Blick aber schlechter abschneidet. Wenige Fehler koennen trotzdem sehr schwere Fehler sein.",
            "Das Surplus-Diagramm zeigt, wie gut Ueberschussenergie genutzt wurde. Hohe Ueberschuesse bedeuten, dass erneuerbare Erzeugung nicht sinnvoll gespeichert oder verbraucht wurde. Claude und Naive schneiden hier schlecht ab, waehrend Codex sehr wenig Ueberschuss hat. RuleBased liegt ebenfalls niedrig.",
            "Die Frequenzgrafik ist ein physikalischer Stabilitaetscheck. Eine Strategie mit grossen Bilanzfehlern verursacht groessere Frequenzabweichungen. Deshalb passt die Frequenzauswertung gut zur unversorgten Energie. RuleBased bleibt am stabilsten, Claude und Naive schwanken staerker.",
            "Das Streudiagramm ist besonders wichtig, weil jeder Punkt ein einzelner Lauf ist. Es zeigt, dass die Mittelwerte nicht nur aus einem Ausreisser bestehen. Gleichzeitig erkennt man, welche Strategien zusammenhaengende Punktwolken bilden. Codex liegt deutlich naeher an RuleBased als an Claude, aber immer noch mit hoeherer unversorgter Energie.",
        ],
    ),
    (
        "21. Bedeutung fuer die Forschungsfrage",
        [
            "Die Forschungsfrage fragt nicht einfach, ob KI beeindruckend wirkt. Sie fragt, ob eine KI-Steuerung Versorgungssicherheit in einem erneuerbaren System verbessern kann. Die Messreihen zeigen darauf eine differenzierte Antwort. KI kann einzelne Kennzahlen verbessern, aber sie loest das Problem nicht automatisch.",
            "Claude zeigt, dass ein Sprachmodell ohne harte mathematische Leitplanken riskante Speicherentscheidungen treffen kann. Es reduziert Brownout-Ticks, aber verursacht grosse Energiemengen, die nicht geliefert werden. Fuer die Versorgungssicherheit ist das kein Erfolg, weil die Tiefe der Ausfaelle entscheidend ist.",
            "Codex zeigt ein besseres Bild. Die Bedienung ist stabiler, die Ueberschuesse sind sehr niedrig und die Defizite sind deutlich kleiner als bei Claude. Trotzdem bleibt RuleBased bei unversorgter Energie, Frequenz und Kosten besser. Damit ist Codex ein Hinweis auf Potenzial, aber kein Beweis fuer Ueberlegenheit.",
            "Die Arbeit fuehrt deshalb zu einer vorsichtigen Schlussfolgerung: LLMs koennen fuer Bedienung, Analyse, Erklaerung und vielleicht als Teil eines Controllers hilfreich sein. Fuer die eigentliche Netzregelung brauchen sie aber klare Grenzen, Prognosen und Optimierung. Sonst ist die physikalische Bilanz staerker als die sprachliche Plausibilitaet.",
            "Diese Antwort passt gut zum Niveau einer Physik-Seminararbeit. Sie verbindet Modellbildung, Messung, Vergleich und Fehlerdiskussion. Das Ergebnis ist nicht nur eine Meinung ueber KI, sondern folgt aus reproduzierbaren Simulationsdaten. Gerade dadurch wird die Aussage verteidigbar.",
        ],
    ),
    (
        "22. Wirtschaftlichkeit und Rentabilitaet",
        [
            "Die Wirtschaftlichkeit ist fuer die Arbeit wichtig, weil ein Stromsystem nicht nur technisch funktionieren muss. Es muss auch bezahlbar bleiben. Im Simulator werden deshalb Kosten berechnet. Dazu gehoeren Betriebskosten, Speicherverluste, CO2-Kosten, Markterloese und vor allem Kosten fuer nicht gelieferte Energie.",
            "Der groesste Kostentreiber ist unversorgte Energie. Das ist sinnvoll, weil ein Stromausfall fuer Haushalte, Betriebe und Industrie teuer ist. Wenn in einem Zeitschritt viel Energie fehlt, entstehen im Modell hohe Value-of-Lost-Load-Kosten. Dadurch wird sichtbar, dass Versorgungssicherheit auch wirtschaftlich entscheidend ist.",
            "Markterloese duerfen dabei nicht falsch verstanden werden. Wenn ein Speicher Strom entlaedt, ist das nicht automatisch neue Erzeugung. Der Strom wurde vorher schon erzeugt und gespeichert. Deshalb muss man aufpassen, dieselbe Energie nicht doppelt als Gewinn zu zaehlen. Genau deshalb wurde die wirtschaftliche Auswertung vorsichtiger gemacht.",
            "RuleBased ist in den Messreihen am guenstigsten, obwohl es mehr Brownout-Ticks hat. Der Grund ist, dass diese Defizite kleiner sind. Codex ist teurer als RuleBased, aber deutlich guenstiger als Claude und Naive. Das zeigt, dass die wirtschaftliche Bewertung fast dieselbe Geschichte erzaehlt wie die physikalische Bewertung ueber unversorgte Energie.",
            "Fuer die Rentabilitaet eines erneuerbaren Systems heisst das: Es reicht nicht, moeglichst viel Strom zu produzieren. Die Erzeugung muss zum Bedarf passen oder gut gespeichert werden. Sonst entstehen entweder hohe Defizitkosten oder Ueberschuss, der keinen Nutzen bringt. Gute Steuerung ist deshalb ein wirtschaftlicher Wert, nicht nur ein technisches Detail.",
        ],
    ),
    (
        "23. Warum der Tabellenanhang wichtig ist",
        [
            "Der Text arbeitet mit Mittelwerten, damit die Hauptaussagen verstaendlich bleiben. Mittelwerte sind aber immer eine Zusammenfassung. Fuer eine wissenschaftliche Arbeit muss man trotzdem nachvollziehen koennen, welche Einzellaeufe dahinterstehen. Deshalb gibt es am Ende einen Tabellenanhang mit allen Messreihen.",
            "Der Tabellenanhang erlaubt dem Pruefer, einzelne Seeds zu kontrollieren. Man kann zum Beispiel sehen, ob ein schlechter Mittelwert durch alle Laeufe entsteht oder ob ein einzelner Ausreisser besonders stark wirkt. Diese Transparenz ist wichtig, weil Simulationen sonst wie eine Blackbox wirken koennen.",
            "Besonders bei KI-Laeufen ist diese Offenheit notwendig. Eine KI kann bei einem Seed gut und bei einem anderen Seed schlecht reagieren. Wenn nur ein Durchschnitt genannt wuerde, koennte man diese Unterschiede nicht mehr sehen. Die Tabellen zeigen deshalb Brownouts, unversorgte Energie, Ueberschuss, Frequenz und Kosten je Lauf.",
            "Die Tabellen sind nicht als Fliesstext gedacht, sondern als Nachweis. Im Hauptteil wird erklaert, was die Zahlen bedeuten. Im Anhang stehen die Rohwerte in kompakter Form. So bleibt der Text lesbar, aber die Auswertung bleibt pruefbar.",
            "Die maschinenlesbaren CSV-Dateien bleiben zusaetzlich im Messreihenordner erhalten. Das ist praktisch, wenn spaeter weitere Diagramme erzeugt oder Werte kontrolliert werden sollen. Fuer die Seminararbeit ist dadurch klar: Die Aussagen beruhen nicht auf handgeschriebenen Schaetzungen, sondern auf reproduzierbaren Simulationslaeufen.",
        ],
    ),
    (
        "24. Grenzen des Modells",
        [
            "Das Modell ist ein Sammelknoten. Es gibt keine Leitungen, keine Spannungsebenen, keine Netzengpaesse und keine Ortsabhaengigkeit. In einem echten Netz koennte Strom an einer Stelle fehlen, obwohl er an einer anderen Stelle vorhanden ist. Diese Effekte werden hier nicht betrachtet.",
            "Das Wetter ist synthetisch. Es ist reproduzierbar und fuer den Vergleich fair, aber nicht direkt eine echte historische Wetterlage. Fuer eine echte technische Planung muesste man reale Messdaten verwenden. Fuer die Seminararbeit ist das synthetische Wetter aber ausreichend, weil die Strategien unter gleichen Bedingungen verglichen werden.",
            "Auch die Frequenz ist stark vereinfacht. Die echte Netzfrequenz haengt von vielen dynamischen Prozessen ab, die in Sekunden oder Millisekunden ablaufen. Das Modell nutzt eine grobe Naeherung, um Bilanzfehler sichtbar zu machen. Es ist kein Ersatz fuer eine echte Netzstabilitaetsrechnung.",
            "Die Kostenrechnung ist ebenfalls ein Modell. Besonders der Value of Lost Load ist eine Annahme. Je nachdem, welchen Wert man dafuer waehlt, aendern sich die absoluten Kosten. Die Reihenfolge der Strategien bleibt aber plausibel, weil nicht gelieferte Energie immer sehr teuer sein muss.",
            "Trotz dieser Grenzen ist das Modell fuer die Forschungsfrage geeignet. Es zeigt klar, dass Steuerung nicht nur CO2 senken muss, sondern Versorgungssicherheit herstellen muss. Und es zeigt, dass ein LLM allein noch nicht automatisch ein guter Netzregler ist.",
        ],
    ),
    (
        "25. Gesamtauswertung und Fazit",
        [
            "Die wichtigste Erkenntnis lautet: Die beste Strategie haengt davon ab, welche Messgroesse man betrachtet. Claude gewinnt bei der reinen Anzahl der Brownout-Ticks, verliert aber bei unversorgter Energie, Frequenz, Surplus und Kosten. Codex liegt naeher an RuleBased und ist deutlich besser als Claude, erreicht aber RuleBased bei der unversorgten Energie nicht.",
            "Aus physikalischer Sicht ist RuleBased die sicherste Vergleichsstrategie. Sie verhindert tiefe Defizite am besten und haelt die Frequenz stabiler. Das liegt daran, dass sie Speicher systematisch nach Wirkungsgrad und Rolle nutzt. Besonders die vorsichtige Behandlung von Wasserstoff ist wichtig.",
            "Codex zeigt, dass eine agentische Bedienung der Software deutlich besser sein kann als die Claude-Live-Laeufe. Die Ergebnisse sind stabil und die Energieverschwendung ist sogar sehr gering. Trotzdem bleibt ein Restproblem: Die Defizite sind tiefer als bei RuleBased. Auch Codex braucht also eine genauere Speicherplanung.",
            "Fuer die Hypothese der Arbeit bedeutet das: Eine LLM-basierte Steuerung kann einzelne Kennzahlen verbessern, aber sie uebertrifft die regelbasierte Heuristik nicht insgesamt. Besonders bei sicherheitskritischen Groessen ist RuleBased klar staerker. Damit wird die einfache Aussage 'KI ist besser' nicht bestaetigt.",
            "Das Ergebnis ist trotzdem wertvoll. Es zeigt nicht nur, welche Strategie besser ist, sondern warum. Die Schwachstelle liegt in langfristiger Energiebilanz und Speicherbudgetierung. Genau dort koennte eine zukuenftige KI-Steuerung verbessert werden, zum Beispiel durch Kombination mit Optimierungsalgorithmen.",
            "Fuer die Energiewende ist dieser Befund wichtig. In einem 100 Prozent erneuerbaren System reicht es nicht, viel Erzeugungsleistung zu haben. Entscheidend ist, wann Energie verfuegbar ist und wie Speicher eingesetzt werden. Die Simulation macht diesen Zusammenhang sichtbar und messbar.",
        ],
    ),
]


def setup_document() -> Document:
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Inches(8.5)
    sec.page_height = Inches(11)
    sec.top_margin = Inches(1)
    sec.bottom_margin = Inches(1)
    sec.left_margin = Inches(1)
    sec.right_margin = Inches(1)
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.line_spacing = 1.333
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    for name, size, color in [
        ("Title", 22, "0B2545"),
        ("Heading 1", 16, "2E74B5"),
        ("Heading 2", 13, "2E74B5"),
        ("Heading 3", 12, "1F4D78"),
    ]:
        st = styles[name]
        st.font.name = "Calibri"
        st.font.size = Pt(size)
        st.font.color.rgb = RGBColor.from_string(color)
        st.paragraph_format.space_before = Pt(12 if name != "Title" else 0)
        st.paragraph_format.space_after = Pt(8)
    return doc


def add_caption(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(10)
    run = p.add_run(text)
    run.italic = True
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(90, 90, 90)


def add_title_page(doc: Document) -> None:
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(18)
    r = title.add_run("Teil der Physik-Seminararbeit")
    r.font.size = Pt(16)
    r.font.color.rgb = RGBColor(80, 80, 80)
    title2 = doc.add_paragraph()
    title2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title2.add_run("Smart-Grid-Simulation: Modell, Steuerung und Messreihen")
    r.bold = True
    r.font.size = Pt(24)
    r.font.color.rgb = RGBColor(11, 37, 69)
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.paragraph_format.space_after = Pt(20)
    r = sub.add_run("Vergleich von RuleBased, Claude Live und Codex Operator in einem 100 Prozent erneuerbaren Stromsystem")
    r.font.size = Pt(12)
    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta.add_run("Stand: 19.05.2026\n").bold = True
    meta.add_run("Datenbasis: 90 indexierte Simulationslaeufe, 15 Seeds, 96 Ticks pro Lauf\n")
    meta.add_run("Dieser Text ist als eigenstaendiger Teil der Seminararbeit gedacht.")
    doc.add_page_break()


def add_source_notice(doc: Document) -> None:
    doc.add_heading("Quellenhinweis", level=1)
    doc.add_paragraph(
        "Die Auswertung in diesem Teil stuetzt sich zuerst auf eigene Primaerquellen: den Programmcode "
        "der Simulationssoftware sgsim und die geordneten Messreihen im Ordner smartgrid_messreihen. "
        "Alle Zahlen, Diagramme und Tabellen zu Brownouts, unversorgter Energie, Ueberschuss, Frequenz "
        "und Kosten wurden aus diesen Messreihen berechnet. Dafuer werden im Detailquellenblatt die "
        "Quellen Q1 und Q2 angegeben."
    )
    doc.add_paragraph(
        "Externe wissenschaftliche oder technische Quellen wurden nur fuer allgemeine Hintergruende "
        "verwendet, zum Beispiel fuer Leistung und Energie, Speichertechnologien, Elektrolyse, "
        "Frequenzstabilitaet und Value of Lost Load. Diese Quellen sind im Text nicht als Zahlenbasis "
        "der Messreihen zu verstehen, sondern als fachliche Einordnung. Die Detailquellen stehen am "
        "Ende des Dokuments und zusaetzlich im separaten Quellenblatt Detailquellenblatt.xlsx."
    )
    doc.add_paragraph(
        "Kurz gesagt: Die Simulationsergebnisse sind eigene Messdaten. Die externen Quellen erklaeren, "
        "warum die benutzten physikalischen und wirtschaftlichen Begriffe sinnvoll sind."
    )
    doc.add_page_break()


def add_main_text(doc: Document) -> None:
    for heading, paragraphs in MAIN_SECTIONS:
        doc.add_heading(heading, level=1)
        for para in paragraphs:
            doc.add_paragraph(para)


def add_charts_section(doc: Document, charts: dict[str, Path]) -> None:
    doc.add_page_break()
    doc.add_heading("Diagrammteil", level=1)
    doc.add_paragraph(
        "Die folgenden Diagramme zeigen dieselben Ergebnisse wie der Text, aber in kompakter Form. "
        "Sie sind aus dem geordneten Master-Index der Messreihen neu erzeugt worden."
    )
    chart_items = [
        ("brownout_unserved", "Abbildung 1: Brownout-Anzahl und unversorgte Energie. Die rote Saeule ist zur besseren Lesbarkeit durch 20 geteilt."),
        ("surplus_cost", "Abbildung 2: Ueberschussenergie und Tageskosten. Die Kostensaeule ist skaliert, damit beide Groessen gemeinsam sichtbar sind."),
        ("freq", "Abbildung 3: Maximale Frequenzabweichung. Niedrigere Werte bedeuten stabilere Bilanz zwischen Erzeugung und Verbrauch."),
        ("scatter", "Abbildung 4: Jeder Punkt ist ein Simulationslauf. Man sieht, dass wenige Brownouts nicht automatisch wenig unversorgte Energie bedeuten."),
        ("h2", "Abbildung 5: H2-Speicherverlauf fuer Seed 42. Der Speicher ist entscheidend fuer die Abendspitze."),
    ]
    for key, caption in chart_items:
        doc.add_picture(str(charts[key]), width=Inches(6.2))
        last = doc.paragraphs[-1]
        last.alignment = WD_ALIGN_PARAGRAPH.CENTER
        add_caption(doc, caption)


def add_tables_section(doc: Document) -> None:
    doc.add_page_break()
    doc.add_heading("Tabellarischer Anhang der Messreihen", level=1)
    doc.add_paragraph(
        "Der Anhang enthaelt die wichtigsten Messwerte aller Laeufe. Die vollstaendige maschinenlesbare "
        "Datei liegt zusaetzlich unter smartgrid_messreihen/00_ueberblick/master_index.csv."
    )

    agg_display = [
        ["Baseline", "Naive", "15", fmt_de(BASELINE_NAIVE["brownout_steps_mean"]), fmt_de(BASELINE_NAIVE["unserved_energy_mwh_mean"]), fmt_de(BASELINE_NAIVE["surplus_energy_mwh_mean"]), fmt_de(million(BASELINE_NAIVE["total_cost_eur_mean"]), 2)],
        ["Baseline", "RuleBased", "15", fmt_de(BASELINE_RB["brownout_steps_mean"]), fmt_de(BASELINE_RB["unserved_energy_mwh_mean"]), fmt_de(BASELINE_RB["surplus_energy_mwh_mean"]), fmt_de(million(BASELINE_RB["total_cost_eur_mean"]), 2)],
        ["Claude", "Claude Live", "15", fmt_de(CLAUDE_ALL["brownout_steps_mean"]), fmt_de(CLAUDE_ALL["unserved_energy_mwh_mean"]), fmt_de(CLAUDE_ALL["surplus_energy_mwh_mean"]), fmt_de(million(CLAUDE_ALL["total_cost_eur_mean"]), 2)],
        ["Codex", "Codex Operator", "45", fmt_de(CODEX_ALL["brownout_steps_mean"]), fmt_de(CODEX_ALL["unserved_energy_mwh_mean"]), fmt_de(CODEX_ALL["surplus_energy_mwh_mean"]), fmt_de(million(CODEX_ALL["total_cost_eur_mean"]), 2)],
    ]
    doc.add_heading("Tabelle A1: Zusammenfassung nach Strategiegruppe", level=2)
    add_table(
        doc,
        ["Gruppe", "Strategie", "n", "Brownouts", "Unserved MWh", "Surplus MWh", "Kosten Mio. EUR"],
        agg_display,
        widths=[0.9, 1.2, 0.45, 0.85, 1.1, 1.0, 1.1],
        font_size=8,
    )

    def compact_rows(source: str) -> list[list[str]]:
        rows = [r for r in MASTER_ROWS if r["source_group"] == source]
        rows.sort(key=lambda r: (r["series"], r["controller"], int(r["seed"])))
        out = []
        for r in rows:
            out.append([
                r["series"],
                r["controller"].replace("claude_subagent", "claude").replace("codex_operator", "codex_r1"),
                r["seed"],
                str(int(float(r["brownout_steps"]))),
                fmt_de(float(r["unserved_energy_mwh"]), 1),
                fmt_de(float(r["surplus_energy_mwh"]), 1),
                fmt_de(float(r["peak_deficit_mw"]), 1),
                fmt_de(float(r["max_frequency_deviation_hz"]), 3),
                fmt_de(million(float(r["total_cost_eur"])), 2),
            ])
        return out

    headers = ["Reihe", "Controller", "Seed", "Brown.", "Unserved", "Surplus", "PeakDef", "max df", "Kosten"]
    widths = [0.75, 1.05, 0.45, 0.55, 0.8, 0.75, 0.7, 0.65, 0.75]
    doc.add_heading("Tabelle A2: Baseline-Laeufe", level=2)
    add_table(doc, headers, compact_rows("baseline"), widths=widths, font_size=7)
    doc.add_heading("Tabelle A3: Claude-Live-Laeufe", level=2)
    add_table(doc, headers, compact_rows("claude_live"), widths=widths, font_size=7)
    doc.add_heading("Tabelle A4: Codex-Operator-Laeufe", level=2)
    add_table(doc, headers, compact_rows("codex_operator"), widths=widths, font_size=7)


def add_detail_sources_section(doc: Document) -> None:
    doc.add_page_break()
    doc.add_heading("Detailquellenblatt", level=1)
    doc.add_paragraph(
        "Dieses Quellenblatt trennt eigene Datenquellen von externen Hintergrundquellen. "
        "Die Messwerte der Arbeit stammen aus Q1 und Q2. Die Quellen Q3 bis Q9 wurden nur "
        "zur fachlichen Einordnung genutzt."
    )
    rows = []
    for src in SOURCE_REFERENCES:
        rows.append([src["id"], src["source"], src["type"], src["used_for"]])
    add_table(
        doc,
        ["ID", "Quelle", "Art", "Verwendung im Text"],
        rows,
        widths=[0.45, 2.25, 1.25, 2.55],
        font_size=7,
    )
    doc.add_heading("Vollstaendige Pfade und Links", level=2)
    for src in SOURCE_REFERENCES:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(f'{src["id"]}: {src["detail"]}')
        r.font.size = Pt(8)
        r.font.name = "Calibri"
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(f'Hinweis: {src["note"]}')
        r.font.size = Pt(8)
        r.font.name = "Calibri"
        r.italic = True


def write_detail_sources_workbook() -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Detailquellen"
    headers = ["ID", "Quellenart", "Quelle", "Pfad oder URL", "Verwendung im Text", "Hinweis"]
    ws.append(headers)
    for src in SOURCE_REFERENCES:
        ws.append([
            src["id"],
            pretty_german(src["type"]),
            pretty_german(src["source"]),
            src["detail"],
            pretty_german(src["used_for"]),
            pretty_german(src["note"]),
        ])

    header_fill = PatternFill("solid", fgColor="E8EEF5")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="0B2545")
        cell.fill = header_fill
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    widths = [8, 24, 44, 72, 58, 52]
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    for idx in range(2, len(SOURCE_REFERENCES) + 2):
        ws.row_dimensions[idx].height = 58
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    wb.save(SOURCE_XLSX_PATH)


def add_footer(doc: Document) -> None:
    for section in doc.sections:
        footer = section.footer
        p = footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("Smart-Grid-Simulation - Modell und Messreihen")
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(100, 100, 100)


def main() -> None:
    charts = make_charts()
    write_detail_sources_workbook()
    doc = setup_document()
    add_title_page(doc)
    add_source_notice(doc)
    add_main_text(doc)
    add_charts_section(doc, charts)
    add_tables_section(doc)
    add_detail_sources_section(doc)
    add_footer(doc)
    prettify_document_text(doc)
    doc.save(DOCX_PATH)
    print(DOCX_PATH)
    print(SOURCE_XLSX_PATH)


if __name__ == "__main__":
    main()
