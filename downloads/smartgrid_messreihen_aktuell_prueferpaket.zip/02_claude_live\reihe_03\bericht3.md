# Messreihen-Bericht 3: Zweite Replikation des Strategie-Vergleichs (sgsim)

**Pilot-Auswertung Reihe 3 (n = 5 neue Seeds) + kombinierte Auswertung n = 15**

| | |
|---|---|
| **Datum des Laufs** | 2026-05-02 (gleicher Tag wie R1+R2, ca. 2 h später) |
| **sgsim-Version** | 0.1.0 |
| **Szenario** | `stadt_mittel.yaml` (intern: `stadt_mittel_erneuerbar`) — identisch |
| **Simulationshorizont** | 24 h = 96 Ticks à 15 min (identisch) |
| **Seeds Reihe 3** | **5, 19, 41, 67, 88** (disjunkt zu R1 {7,13,23,42,99} und R2 {3,17,31,55,73}) |
| **Strategien** | `naive`, `rule_based`, `claude_subagent` (identisch) |
| **Subagent-Prompt** | **Wortgleich** zu R1+R2 (Replikations-Bedingung) |
| **Anzahl neue Einzelläufe** | 5 × 3 = **15** |
| **Gesamt-Stichprobe nach R3** | 15 × 3 = **45 Läufe** |
| **Bezug** | [`bericht.md`](bericht.md), [`bericht2.md`](bericht2.md) |

---

## 1. Forschungsdesign

Reihe 3 ist die **zweite unabhängige Replikation** desselben Experiments. Methodik, Software-Version, Szenario, Subagent-Prompt — alles identisch zu Reihe 1 und 2. Einziger Unterschied: weitere fünf neue Seeds.

Ziel: die in R1 und R2 gefundenen Effekte mit einer **dritten unabhängigen Stichprobe** prüfen und die kombinierte Statistik auf n = 15 pro Strategie erhöhen. n = 15 ist eine in der wissenschaftlichen Praxis akzeptierte Stichprobengröße für vergleichende Studien mit großen Effektstärken.

---

## 2. Roh-Ergebnisse Reihe 3

> Vollständige maschinenlesbare Tabelle aller 45 Läufe:
> [`full_metrics_n15.csv`](full_metrics_n15.csv)
> Konsolen-Aggregationen: [`aggregation_r3.txt`](aggregation_r3.txt) und [`aggregation_n15.txt`](aggregation_n15.txt)

### 2.1 Versorgungssicherheit & Energie-Bilanz (R3)

| Controller | Seed | Brownouts | Unserved [MWh] | Surplus [MWh] | Peak Defizit [MW] | Max Δf [Hz] | Ticks außer Toleranz |
|---|---:|---:|---:|---:|---:|---:|---:|
| naive | 5 | 59 | 1227.17 | 415.85 | 183.20 | 0.916 | 66 |
| naive | 19 | 59 | 1250.96 | 410.22 | 184.40 | 0.922 | 66 |
| naive | 41 | 60 | 1257.38 | 424.88 | 184.21 | 0.921 | 62 |
| naive | 67 | 59 | 1273.17 | 394.03 | 184.13 | 0.921 | 64 |
| naive | 88 | 59 | 1253.92 | 400.90 | 182.66 | 0.913 | 64 |
| rule_based | 5 | 64 | 201.79 | 26.55 | 66.44 | 0.332 | 3 |
| rule_based | 19 | 62 | 235.72 | 29.76 | 70.77 | 0.354 | 6 |
| rule_based | 41 | 63 | 225.40 | 28.36 | 79.25 | 0.396 | 5 |
| rule_based | 67 | 66 | 264.89 | 21.81 | 77.94 | 0.390 | 8 |
| rule_based | 88 | 60 | 242.62 | 25.05 | 76.59 | 0.383 | 6 |
| claude_subagent | 5 | 54 | 875.53 | 607.11 | 133.39 | 0.667 | 66 |
| claude_subagent | 19 | **67** | 1223.71 | 831.53 | 193.29 | 1.000 | 67 |
| claude_subagent | 41 | 60 | 831.95 | 477.30 | 169.54 | 0.848 | 52 |
| claude_subagent | 67 | 58 | 1077.38 | 650.64 | 192.92 | 1.000 | 52 |
| claude_subagent | 88 | 52 | 1135.76 | 745.95 | 205.67 | 1.000 | 65 |

> **Auffälligkeit Seed 19:** Mit 67 Brownouts erreichte der Subagent denselben Wert wie der Worst-Case-RuleBased-Lauf — der höchste Brownout-Wert aller bisherigen 15 Subagent-Läufe. Das illustriert die größere Streuung von Claude (SD = 5.85 in R3 gegenüber SD = 2.24 bei RuleBased).

### 2.2 Erzeugung, CO₂, Wirtschaftlichkeit (R3)

| Controller | Seed | Renewable Share [%] | CO₂ [kg] | Total Cost [EUR] | Net [EUR] |
|---|---:|---:|---:|---:|---:|
| naive | 5 | 57.72 | 26733.75 | 8 777 442 | -8 447 327 |
| naive | 19 | 57.11 | 26733.75 | 8 943 990 | -8 616 135 |
| naive | 41 | 57.28 | 26733.75 | 8 988 917 | -8 661 672 |
| naive | 67 | 56.32 | 26733.75 | 9 099 500 | -8 773 755 |
| naive | 88 | 56.86 | 26733.75 | 8 964 749 | -8 637 176 |
| rule_based | 5 | 58.35 | 26733.75 | 1 602 223 | -1 174 697 |
| rule_based | 19 | 57.72 | 26733.75 | 1 839 713 | -1 415 410 |
| rule_based | 41 | 57.90 | 26733.75 | 1 767 442 | -1 342 159 |
| rule_based | 67 | 56.93 | 26733.75 | 2 043 925 | -1 622 394 |
| rule_based | 88 | 57.47 | 26733.75 | 1 888 021 | -1 464 374 |
| claude_subagent | 5 | 53.83 | 26907.00 | 6 325 391 | (n/a) |
| claude_subagent | 19 | 49.92 | 27022.50 | 8 767 521 | (n/a) |
| claude_subagent | 41 | 52.50 | 26984.00 | 6 022 243 | (n/a) |
| claude_subagent | 67 | 49.71 | 27099.50 | 7 744 885 | (n/a) |
| claude_subagent | 88 | 50.43 | 27041.75 | 8 151 736 | (n/a) |

---

## 3. Aggregat Reihe 3 (n = 5)

| Metrik | Naive | RuleBased | **ClaudeSubagent** |
|---|---:|---:|---:|
| Brownouts [Ticks] | 59.20 ± 0.45 | 63.00 ± 2.24 | **58.20 ± 5.85** |
| Unserved Energy [MWh] | 1252.52 ± 16.56 | **234.09 ± 23.15** | 1028.87 ± 168.84 |
| Surplus Energy [MWh] | 409.18 ± 12.15 | **26.31 ± 3.08** | 662.51 ± 135.13 |
| CO₂ [t] | 26.73 ± 0.00 | 26.73 ± 0.00 | 27.01 ± 0.07 |
| Renewable Share [%] | 57.06 ± 0.52 | **57.68 ± 0.52** | 51.28 ± 1.80 |

### Welch-t und Cohen's d Reihe 3 (claude_subagent vs. rule_based)

| Metrik | t | Cohen's d | Signifikanz |
|---|---:|---:|---|
| Brownouts [Ticks] | **−1.71** | **−1.08** | **n.s.** (nicht signifikant in R3 allein) |
| CO₂ [t] | +8.67 | +5.48 | `***` p < 0.001 |
| Surplus [MWh] | +10.52 | +6.66 | `***` p < 0.001 |

> **Wichtige Beobachtung:** In Reihe 3 alleine ist der Brownout-Vorteil von Claude **erstmals nicht statistisch signifikant** (|t| = 1.71 < 1.96). Grund: ein Worst-Case-Lauf bei Seed 19 (67 Brownouts) zog den Mittelwert nach oben und vergrößerte die Streuung. Die Effektgröße bleibt mit |d| = 1.08 aber im Bereich "großer Effekt" — sie ist nur durch die Stichprobengröße n = 5 nicht abgesichert. **Die kombinierte Auswertung (§5) zeigt dagegen wieder eindeutige Signifikanz.**

---

## 4. Vergleich aller drei Reihen

### 4.1 Brownouts (Hauptmetrik)

| | Reihe 1 | Reihe 2 | **Reihe 3** | Kombiniert n=15 |
|---|---:|---:|---:|---:|
| Naive | 60.20 ± 1.64 | 60.20 ± 0.84 | 59.20 ± 0.45 | **59.87 ± 1.13** |
| RuleBased | 65.00 ± 2.35 | 63.20 ± 3.11 | 63.00 ± 2.24 | **63.73 ± 2.58** |
| ClaudeSubagent | 52.80 ± 6.53 | 55.40 ± 2.51 | 58.20 ± 5.85 | **55.47 ± 5.38** |
| t (Cl vs. RB) | −3.93 `***` | −4.36 `***` | −1.71 n.s. | **−5.36 `***`** |
| Cohen's d (Cl vs. RB) | −2.49 | −2.76 | −1.08 | **−1.96** |

### 4.2 Robustheits-Befund

Über drei unabhängige Reihen schwankt der Brownout-Effekt zwischen **|d| = 1.08 und |d| = 2.76** — der Effekt ist also **nicht konstant**, aber **immer in dieselbe Richtung** (Claude reduziert Brownouts). Mit kombinierten n = 15 ist die Effektgröße |d| = 1.96 (großer Effekt) und der Effekt **hochsignifikant** (p < 0.001).

Andere Metriken (CO₂, Surplus, Frequenz) zeigen über alle drei Reihen praktisch identische Effekte → für diese Größen ist die Replikation **noch sauberer** als für Brownouts.

---

## 5. Kombinierte Statistik n = 15

| Metrik (Mittelwert ± SD) | Naive | RuleBased | **ClaudeSubagent** |
|---|---:|---:|---:|
| Brownouts [Ticks] | 59.87 ± 1.13 | 63.73 ± 2.58 | **55.47 ± 5.38** |
| Unserved Energy [MWh] | 1248.30 ± 19.20 | **233.25 ± 27.38** | 1028.90 ± 155.65 |
| Surplus Energy [MWh] | 400.41 ± 15.70 | **20.88 ± 5.53** | 667.85 ± 136.28 |
| CO₂ [t] | 26.73 ± 0.00 | 26.73 ± 0.00 | 27.02 ± 0.12 |
| Renewable Share [%] | 56.96 ± 0.57 | **57.58 ± 0.58** | 51.44 ± 1.53 |
| Peak Defizit [MW] | 183.05 ± 2.15 | **73.26 ± 11.31** | 185.35 ± 39.61 |
| Max Δf [Hz] | 0.915 ± 0.011 | **0.366 ± 0.057** | 0.935 ± 0.104 |
| Ticks außerhalb Frequenz-Toleranz | 64.1 ± 3.1 | **5.1 ± 1.8** | 62.3 ± 9.2 |

### Welch-t und Cohen's d kombiniert n = 15 (claude_subagent vs. rule_based)

| Metrik | t | Cohen's d | Signifikanz |
|---|---:|---:|---|
| Brownouts [Ticks] | **−5.36** | **−1.96** | `***` p < 0.001 |
| CO₂ [t] | **+9.59** | **+3.50** | `***` p < 0.001 |
| Surplus [MWh] | **+18.37** | **+6.71** | `***` p < 0.001 |
| Peak Defizit [MW] | **+10.54** | **+3.85** | `***` p < 0.001 |
| Max Δf [Hz] | **+18.66** | **+6.81** | `***` p < 0.001 |
| Ticks außerhalb Frequenz-Toleranz | **+23.68** | **+8.65** | `***` p < 0.001 |

### 5.1 Entwicklung der Effektgrößen mit wachsender Stichprobe

| Metrik | n=5 (R1) | n=10 (R1+R2) | **n=15 (R1+R2+R3)** |
|---|---:|---:|---:|
| Brownouts (Cohen's d) | −2.49 | −2.53 | **−1.96** |
| CO₂ (Cohen's d) | +2.18 | +3.04 | **+3.50** |
| Surplus (Cohen's d) | +11.83 | +6.40 | **+6.71** |
| Peak Defizit (Cohen's d) | (n/a) | +3.47 | **+3.85** |
| Max Δf (Cohen's d) | (n/a) | +7.98 | **+6.81** |

> Die Brownout-Effektgröße schwächt sich von n=10 zu n=15 leicht ab (von |d| = 2.53 auf |d| = 1.96), bleibt aber im Bereich "großer Effekt". Alle anderen Metriken zeigen stabile oder leicht wachsende Effektgrößen — die Aussage wird also **robuster, nicht schwächer**.

---

## 6. Strategie-Beobachtungen aus den R3-Subagents

| Seed | Brownouts | Berichteter Hauptfehler |
|---|---:|---|
| 5 | 54 | H₂-Speicher ab Tick ~60 (15h) auf 0 %; alle Speicher bei 19 h leer; letzte 16 Ticks "Dunkelflaute ohne Reserven". |
| 19 | **67** | H₂ ab Stunde ~16 leer; **2 frühe Brownout-Phasen** durch Unterschätzung des morgendlichen Lastanstiegs; massive Defizite 16-24 h. |
| 41 | 60 | Wind in Seed 41 deutlich schwächer als Brief-Tagesgang (~10–15 MW statt 25–30); Lade-Lasten zur Mittagszeit zu aggressiv; H₂ ab Stunde 17 leer. |
| 67 | 58 | H₂ ab Tick 68 (17 Uhr) komplett leer → Gasturbine lieferte nur 1.9 MW statt der gewünschten 60–200 MW; Wind schwächer als Brief; "klassische Dunkelflauten-Situation". |
| 88 | 52 | Wind nur ~10–25 MW statt 35–50; H₂-Speicher nach 18 h auf 0 %; Phase 5–6 zu aggressives Speicher-Laden → Defizite > 200 MW. |

**Replikations-Befund verschärft:** In jetzt **15 von 15 unabhängigen LLM-Läufen** (R1 + R2 + R3) ist exakt derselbe Hauptfehler aufgetreten — der H₂-Saisonspeicher wird zu früh entleert. Die Reproduzierbarkeit dieses Befundes ist **maximal robust**: nicht ein einziger Subagent hat die globale Energiebudget-Planung über 24 h hinweg gemeistert. Drei der fünf R3-Subagents nennen zusätzlich **Wetter-Unterschätzung** als Co-Faktor (vor allem für Seeds 41, 67, 88, in denen Wind unterhalb des im Brief skizzierten Tagesgangs lag).

---

## 7. Interpretation für die Seminararbeit

### 7.1 Aktualisierte differenzierte Antwort (n = 15)

| Dimension | Sieger | t (Cl vs. RB) | |d| | Robustheit über Reihen |
|---|---|---:|---:|---|
| Brownout-Häufigkeit | **Claude** | −5.36 | 1.96 | gut, in R3 grenzwertig |
| Versorgungssicherheit (Unserved Energy) | **RuleBased** | (≈ +12) | ≈ 6 | sehr gut |
| Frequenzstabilität (Max Δf) | **RuleBased** | +18.66 | 6.81 | sehr gut |
| Frequenzstabilität (Ticks außer Toleranz) | **RuleBased** | +23.68 | 8.65 | sehr gut |
| Peak Defizit | **RuleBased** | +10.54 | 3.85 | sehr gut |
| CO₂-Emissionen | **RuleBased** | +9.59 | 3.50 | sehr gut |
| Energieverschwendung (Surplus) | **RuleBased** | +18.37 | 6.71 | sehr gut |
| Wirtschaftlichkeit | **RuleBased** | (≫ 10) | (≫ 5) | sehr gut |
| Renewable Share | RuleBased | (mittel) | ≈ 5 | sehr gut |

### 7.2 Aktualisierter Kerntext-Vorschlag (zitierfähig)

> Über drei unabhängige Replikations-Reihen mit insgesamt fünfzehn Seeds (n = 15 pro Strategie, 45 Simulationsläufe insgesamt) zeigt sich ein konsistentes Bild: Die LLM-Steuerung reduziert die Anzahl der Brownout-Ticks gegenüber einer regelbasierten Heuristik signifikant (p < 0.001, |Cohen's d| = 1.96), erhöht aber zugleich Frequenzabweichung, Peak-Defizit, Energieverschwendung und Tageskosten — sämtlich mit hoch signifikanten Effekten (alle |t| > 9, alle |d| > 3). Die in **15 von 15 Läufen unabhängig identifizierte Ursache** ist eine fehlende globale Energiebudget-Planung des H₂-Saisonspeichers über die 24 h hinweg. Die in der dritten Replikations-Reihe beobachtete Schwächung des Brownout-Effekts (|d| = 1.08 statt 2.49 in R1) zeigt, dass die LLM-Performance auch eine spürbare Streuung zwischen Wetter-Realisierungen aufweist — was eine zusätzliche Schwäche gegenüber der deterministischen RuleBased-Steuerung darstellt.

### 7.3 Methodischer Mehrwert

Die dritte Reihe liefert **zwei zusätzliche Erkenntnisse** über die ersten beiden hinaus:

1. **Die Streuung der LLM-Performance ist real:** R3 zeigt mit Seed 19 einen Lauf, der so schlecht wie das schlechteste RuleBased-Ergebnis war. Das ist in einer Seminararbeit ein wertvoller Punkt — er beweist, dass die KI **nicht zuverlässig** ist, sondern **probabilistisch** funktioniert.
2. **Wetter-Unterschätzung als systematischer Co-Faktor:** Drei der fünf R3-Subagents nennen explizit, dass die im Brief enthaltenen Tagesgang-Hinweise eine Erwartungshaltung erzeugen, die bei "schlechten" Wetter-Realisierungen nicht eintritt. Das ist ein **kognitiver Bias** des Sprachmodells, der in einer Seminararbeit zur LLM-Steuerung als Limitation diskutiert werden kann.

---

## 8. Reproducibility-Hashes (Reihe 3)

| Controller | Seed | Hash |
|---|---:|---|
| naive | 5 | `ca73657c75fc0864` |
| naive | 19 | `6ced1b5ddcb76508` |
| naive | 41 | `161cb0b9838553e8` |
| naive | 67 | `b380b04164f9944d` |
| naive | 88 | `24379366a6d9bcc9` |
| rule_based | 5 | `edbc14d48aecb6c2` |
| rule_based | 19 | `238df2ef1de86fde` |
| rule_based | 41 | `6ba119ea40edfb77` |
| rule_based | 67 | `245c471ff0348714` |
| rule_based | 88 | `79d0e08272a54716` |
| claude_subagent | 5 | `a6c2466507bb7000` |
| claude_subagent | 19 | `274377deb0b3cdcf` |
| claude_subagent | 41 | `9206a24876a6b03d` |
| claude_subagent | 67 | `bdb17a9dbb2d2d30` |
| claude_subagent | 88 | `bc60049b20f32c45` |

> Hashes R1 → [`bericht.md`](bericht.md) §3.4; Hashes R2 → [`bericht2.md`](bericht2.md) §8. Insgesamt **45 Läufe einzeln zitierbar**.

---

## 9. Datenanhang

| Inhalt | Pfad |
|---|---|
| Dieser Bericht | `results/pilot_summary/bericht3.md` |
| Vollständige Tabelle aller 45 Läufe | `results/pilot_summary/full_metrics_n15.csv` |
| Aggregation R3 alleine | `results/pilot_summary/aggregation_r3.txt` |
| Aggregation kombiniert n=15 | `results/pilot_summary/aggregation_n15.txt` |
| R3 Baseline Tick-CSVs | `results/baselines/{naive,rule_based}_seed{5,19,41,67,88}.csv` |
| R3 Baseline Sidecar-Metriken | `results/baselines/{naive,rule_based}_seed{5,19,41,67,88}.metrics.json` |
| R3 Subagent Tick-CSVs | `runs/seed_{05,19,41,67,88}/result.csv` |
| R3 Subagent Sidecar-Metriken | `runs/seed_{05,19,41,67,88}/result.metrics.json` |

### Befehle zur Reproduktion (R3)

```bash
for SEED in 5 19 41 67 88; do
    for CTRL in naive rule_based; do
        sgsim experiment run --controller $CTRL --seed $SEED --steps 96 \
            --out results/baselines/${CTRL}_seed${SEED}.csv
    done
done

# Aggregation R3 alleine
python3.12 scripts/aggregate_pilot.py 5 19 41 67 88

# Aggregation kombiniert n=15
python3.12 scripts/aggregate_pilot.py 3 5 7 13 17 19 23 31 41 42 55 67 73 88 99
```

---

## 10. Zusammenfassung

- **Zweite Replikation erfolgreich**, aber mit interessanter Nuance: in R3 alleine ist der Brownout-Vorteil nicht signifikant (n = 5 zu klein bei wachsender Streuung).
- **Kombinierte n = 15:** alle Hauptbefunde aus Bericht 1 und 2 bleiben hochsignifikant (alle p < 0.001, alle |d| > 1.9).
- **Konsistenter Strategiefehler in 15/15 Läufen.** Der H₂-Speicher-Frühentleerungs-Fehler ist nicht stichprobenabhängig.
- **Neuer Befund aus R3:** Die LLM-Performance hat eine **echte Wetter-Sensitivität** (Worst-Case-Lauf bei Seed 19 mit 67 Brownouts) und einen **systematischen Bias durch die Brief-Tagesgang-Skizze**.
- **Stichprobenniveau jetzt für die Seminararbeit mehr als ausreichend** — der Effekt ist groß genug, dass weitere Reihen die Aussage nur unwesentlich verstärken würden.

*Bericht generiert am 2026-05-02 aus 15 neuen Simulationsläufen (Reihe 3), in den Statistiken kombiniert mit R1 und R2 (Gesamt-Stichprobe 45 Läufe).*
