# Messreihen-Bericht: Strategie-Vergleich Smart-Grid-Simulator (sgsim)

**Pilot-Auswertung n = 5 Seeds, drei Steuerungsstrategien**

| | |
|---|---|
| **Datum des Laufs** | 2026-05-02 |
| **sgsim-Version** | 0.1.0 |
| **Szenario** | `stadt_mittel.yaml` (intern: `stadt_mittel_erneuerbar`) |
| **Erzeugungsmix** | 100 % erneuerbar (PV, Wind, Wasserkraft, Biomasse, Geothermie) + H₂-Gasturbine als Backup |
| **Simulationshorizont** | 24 h = 96 Ticks à 15 min |
| **Seeds** | 7, 13, 23, 42, 99 |
| **Strategien** | `naive` (statische Sollwerte), `rule_based` (deterministische Heuristik), `claude_subagent` (Live-LLM-Steuerung via CLI) |
| **Anzahl Einzelläufe** | 5 × 3 = **15 Simulationsläufe** |

---

## 1. Forschungsfrage

> *Kann eine LLM-Steuerung (Claude) in einem volatilen, 100 %-erneuerbaren
> Stromnetz die Versorgungssicherheit gegenüber regelbasierten Heuristiken
> verbessern, ohne CO₂-Emissionen oder Energieverschwendung deutlich zu
> erhöhen?*

Optimierungsziel laut Master-Brief (`sgsim brief`), in dieser Reihenfolge:
1. **Versorgungssicherheit** — Brownouts (Imbalance < 0) minimieren
2. **CO₂-Emissionen** senken (Erneuerbare bevorzugen)
3. **Energieverschwendung** vermeiden (Curtailment / Surplus minimieren)

---

## 2. Methodik

### 2.1 Setup
- Alle 15 Läufe deterministisch über `--seed` reproduzierbar
- Identische Wetter- und Lastverläufe pro Seed über alle drei Strategien (gleicher Seed → identische Eingangsdaten)
- Persistenz pro Run: `.sgsim_state.json`
- Tick-Zeitreihen als CSV exportiert, Metriken als Sidecar-JSON

### 2.2 Baseline-Strategien (CLI direkt)
Für `naive` und `rule_based`:
```bash
sgsim experiment run --controller <CTRL> --seed <S> --steps 96 \
    --out results/baselines/<CTRL>_seed<S>.csv
```

### 2.3 Live-LLM-Steuerung (Claude-Subagents)
Pro Seed wurde ein eigenständiger Claude-Subagent (general-purpose, Sonnet/Opus-Klasse) im isolierten Working Directory `runs/seed_<NN>/` gestartet. Jeder Subagent:
1. liest den kanonischen Master-Brief via `sgsim brief`,
2. initialisiert das Grid mit `sgsim init --seed <S>`,
3. steuert iterativ über die 96 Ticks per `sgsim state` → `sgsim dispatch …` / `sgsim set-curtailment …` → `sgsim run --steps K` (Block-Strategie, 4–8 Ticks pro Entscheidungs-Block),
4. exportiert am Ende `result.csv` und `result.metrics.json`.

Die Subagents agierten **autonom**, ohne Anthropic-API — sie nutzten ausschließlich CLI-Befehle und Klartext-JSON. Reproducibility-Hashes und Wirtschaftlichkeitswerte wurden nachträglich aus dem persistierten Endzustand berechnet (`experiment.reproducibility_hash`, `economics.compute_economics`).

### 2.4 Aggregation
- Per-Seed-Tabelle und Aggregat-Statistik via `scripts/aggregate_pilot.py 7 13 23 42 99`
- Welch-t-Test und Cohen's d für `claude_subagent` vs. `rule_based`

---

## 3. Roh-Ergebnisse pro Lauf

> Vollständige maschinenlesbare Tabelle: [`full_metrics.csv`](full_metrics.csv) (15 Zeilen × 22 Spalten)
> Reine Aggregations-Konsolen­ausgabe: [`aggregation.txt`](aggregation.txt)

### 3.1 Versorgungssicherheit & Energie-Bilanz

| Controller | Seed | Brownouts | Unserved [MWh] | Surplus [MWh] | Peak Defizit [MW] | Peak Surplus [MW] | Max Δf [Hz] | Ticks außer Toleranz |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| naive | 7 | 61 | 1246.14 | 386.30 | 180.30 | 86.73 | 0.902 | 62 |
| naive | 13 | 62 | 1254.77 | 384.73 | 181.17 | 94.55 | 0.906 | 61 |
| naive | 23 | 61 | 1276.30 | 379.82 | 185.00 | 85.99 | 0.925 | 60 |
| naive | 42 | 59 | 1225.54 | 377.53 | 183.08 | 95.38 | 0.915 | 62 |
| naive | 99 | 58 | 1245.00 | 407.32 | 181.60 | 90.66 | 0.908 | 64 |
| rule_based | 7 | 67 | 243.43 | 19.08 | 76.53 | 18.64 | 0.383 | 5 |
| rule_based | 13 | 67 | 252.04 | 17.50 | 82.73 | 17.34 | 0.414 | 6 |
| rule_based | 23 | 63 | 285.10 | 24.69 | 88.20 | 18.27 | 0.441 | 8 |
| rule_based | 42 | 66 | 225.00 | 12.48 | 80.70 | 16.32 | 0.403 | 4 |
| rule_based | 99 | 62 | 218.20 | 15.88 | 74.55 | 13.02 | 0.373 | 4 |
| claude_subagent | 7 | 62 | 1067.17 | 650.00 | 139.98 | 287.02 | 1.000 | 68 |
| claude_subagent | 13 | 51 | 788.78 | 507.26 | 161.74 | 162.82 | 0.814 | 57 |
| claude_subagent | 23 | 55 | 1053.36 | 643.45 | 156.32 | 187.06 | 0.935 | 68 |
| claude_subagent | 42 | 52 | 941.80 | 614.17 | 190.57 | 170.18 | 0.953 | 61 |
| claude_subagent | 99 | 44 | 943.54 | 702.15 | 169.83 | 224.65 | 1.000 | 58 |

### 3.2 Erzeugung & CO₂

| Controller | Seed | Generation [MWh] | Demand [MWh] | Renewable Share [%] | CO₂ [kg] | CO₂ [kg/MWh] |
|---|---:|---:|---:|---:|---:|---:|
| naive | 7 | 3985.91 | 4845.75 | 56.72 | 26733.75 | 5.517 |
| naive | 13 | 3975.72 | 4845.75 | 56.51 | 26733.75 | 5.517 |
| naive | 23 | 3949.27 | 4845.75 | 55.96 | 26733.75 | 5.517 |
| naive | 42 | 3997.75 | 4845.75 | 56.96 | 26733.75 | 5.517 |
| naive | 99 | 4008.07 | 4845.75 | 57.18 | 26733.75 | 5.517 |
| rule_based | 7 | 4569.14 | 4793.49 | 57.34 | 26733.75 | 5.577 |
| rule_based | 13 | 4558.95 | 4793.49 | 57.12 | 26733.75 | 5.577 |
| rule_based | 23 | 4533.08 | 4793.49 | 56.57 | 26733.75 | 5.577 |
| rule_based | 42 | 4580.98 | 4793.49 | 57.58 | 26733.75 | 5.577 |
| rule_based | 99 | 4592.54 | 4794.86 | 57.78 | 26733.75 | 5.576 |
| claude_subagent | 7 | 5063.89 | 5481.06 | 50.14 | 27349.75 | 4.990 |
| claude_subagent | 13 | 4859.14 | 5140.66 | 53.27 | 26887.75 | 5.230 |
| claude_subagent | 23 | 4774.71 | 5184.61 | 52.30 | 27022.50 | 5.212 |
| claude_subagent | 42 | 5046.18 | 5373.81 | 51.36 | 27003.25 | 5.025 |
| claude_subagent | 99 | 4854.50 | 5095.89 | 54.37 | 26878.12 | 5.274 |

> **Auffälligkeit:** Die Demand-Spalte unterscheidet sich zwischen Strategien. Grund: Sektorkopplungs-Lasten (Wärmepumpen, EV-Flotte, Elektrolyseur) sind dispatchierbar — die Subagents haben diese aktiv hochgefahren, was die Gesamtnachfrage erhöht. RuleBased fährt sie konservativer, naive lässt sie auf Default.

### 3.3 Wirtschaftlichkeit (EUR / 24 h)

| Controller | Seed | Total Cost | VoLL Cost | Fuel Cost | Storage Cost | Market Revenue | Net | LCOE [EUR/MWh] |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| naive | 7 | 8 910 273 | 8 722 995 | 185 006 | 0 | 277 312 | -8 632 961 | 2 235 |
| naive | 13 | 8 970 647 | 8 783 369 | 185 006 | 0 | 277 493 | -8 693 154 | 2 256 |
| naive | 23 | 9 121 409 | 8 934 131 | 185 006 | 0 | 280 422 | -8 840 987 | 2 310 |
| naive | 42 | 8 766 038 | 8 578 760 | 185 006 | 0 | 280 270 | -8 485 768 | 2 193 |
| naive | 99 | 8 902 271 | 8 714 993 | 185 006 | 0 | 280 421 | -8 621 850 | 2 221 |
| rule_based | 7 | 1 893 700 | 1 704 037 | 185 006 | 2 384 | 425 569 | -1 468 130 | 414 |
| rule_based | 13 | 1 953 942 | 1 764 280 | 185 006 | 2 384 | 422 752 | -1 531 190 | 429 |
| rule_based | 23 | 2 185 350 | 1 995 688 | 185 006 | 2 384 | 419 612 | -1 765 738 | 482 |
| rule_based | 42 | 1 764 652 | 1 574 990 | 185 006 | 2 384 | 425 321 | -1 339 331 | 385 |
| rule_based | 99 | 1 717 048 | 1 527 373 | 185 006 | 2 384 | 425 967 | -1 291 081 | 374 |
| claude_subagent | 7 | 7 678 040 | * | * | * | * | * | * |
| claude_subagent | 13 | 5 717 928 | * | * | * | * | * | * |
| claude_subagent | 23 | 7 572 737 | * | * | * | * | * | * |
| claude_subagent | 42 | 6 793 640 | * | * | * | * | * | * |
| claude_subagent | 99 | 6 800 369 | * | * | * | * | * | * |

> *Hinweise:* Der dominierende Kostenfaktor ist immer der **VoLL** (Value of Lost Load, 7000 EUR/MWh, durch Brownouts entstanden) — siehe `methodology.md` §11. Subagent-Total-Costs sind nachgereichte Werte aus dem persistierten Endzustand (Aufschlüsselung im JSON unter `runs/seed_<NN>/result.metrics.json` → `economics`-Block).

### 3.4 Reproducibility-Hashes

| Controller | Seed | Hash |
|---|---:|---|
| naive | 7 | `bff5b108b452f8ec` |
| naive | 13 | `8210019b3f8c0ac5` |
| naive | 23 | `aa1110c632fd8fe8` |
| naive | 42 | `0dab242f1ccbf1a9` |
| naive | 99 | `5fec1c02f5cf1c34` |
| rule_based | 7 | `6555bc77ca639a31` |
| rule_based | 13 | `9aad944eea7d58f7` |
| rule_based | 23 | `8f9879dd6d18c248` |
| rule_based | 42 | `f6603a498ee63ab3` |
| rule_based | 99 | `1ed9d38c1d213c56` |
| claude_subagent | 7 | `8736daf801b9b423` |
| claude_subagent | 13 | `41d4c9f8b163844b` |
| claude_subagent | 23 | `0e722859b9a8744a` |
| claude_subagent | 42 | `3d6d4667506bc511` |
| claude_subagent | 99 | `3ea77c705f620dd7` |

Hash-Berechnung gemäß `experiment.reproducibility_hash()`: SHA über sgsim-Version, Szenario-Inhalt, Seed, Controller-Name, Steps, Python-Version. Damit ist jeder Lauf in der Seminararbeit eindeutig zitierbar.

---

## 4. Aggregat-Statistik (n = 5)

### 4.1 Mittelwerte ± Standardabweichungen

| Metrik | Naive | RuleBased | **ClaudeSubagent** |
|---|---:|---:|---:|
| Brownouts [Ticks] | 60.20 ± 1.64 | 65.00 ± 2.35 | **52.80 ± 6.53** |
| Unserved Energy [MWh] | 1249.55 ± 18.38 | **244.75 ± 26.35** | 958.93 ± 111.93 |
| Surplus Energy [MWh] | 387.14 ± 11.83 | **17.93 ± 4.50** | 623.41 ± 72.26 |
| CO₂ [t] | 26.73 ± 0.00 | 26.73 ± 0.00 | 27.03 ± 0.19 |
| Renewable Share [%] | 56.66 ± 0.47 | **57.28 ± 0.47** | 52.29 ± 1.64 |
| Peak Defizit [MW] | 182.23 ± 1.84 | **80.54 ± 5.31** | 163.69 ± 18.62 |
| Max Δf [Hz] | 0.911 ± 0.009 | **0.403 ± 0.027** | 0.940 ± 0.080 |
| Ticks außerhalb Frequenz-Toleranz | 61.8 ± 1.5 | **5.4 ± 1.7** | 62.4 ± 5.3 |

### 4.2 Welch-t-Test und Cohen's d (claude_subagent vs. rule_based)

| Metrik | t | Cohen's d | Signifikanz | Richtung |
|---|---:|---:|---|---|
| Brownouts [Ticks] | **−3.93** | **−2.49** | p < 0.001 (`***`) | Claude **besser** (weniger Brownouts) |
| CO₂ [t] | +3.44 | +2.18 | p < 0.01 (`**`) | Claude **schlechter** (mehr CO₂) |
| Surplus [MWh] | +18.70 | +11.83 | p < 0.001 (`***`) | Claude **schlechter** (mehr Verschwendung) |

Signifikanzgrenzen aus `scripts/compare_strategies.py`:
- `*` p < 0.05 (|t| > 1.96)
- `**` p < 0.01 (|t| > 2.5)
- `***` p < 0.001 (|t| > 3.5)

---

## 5. Strategie-Beobachtungen aus den Subagent-Berichten

Alle fünf Subagents haben unabhängig voneinander dasselbe strukturelle Problem identifiziert:

> **Der H₂-Saisonspeicher startet bei nur ~47 % SoC (≈ 2 500 MWh).**
> Bei aggressiver Nutzung der H₂-Gasturbine in Vor- und Mittagsstunden ist der Speicher bereits am Nachmittag leer (Tick 60–80) — die Gasturbine fällt damit als Backup für die Abend-Lastspitze (18–22 h) komplett aus. Diese Phase verursacht den Großteil der Brownouts.

Konkrete Beobachtungen pro Seed:

| Seed | Berichteter Hauptfehler |
|---|---|
| 7 | H₂-GuD ab Tick ~64 ohne Brennstoff trotz Setpoint 200 MW; PV/Wind bei Seed 7 schwächer als Brief vermuten ließ. |
| 13 | Tick 20: gleichzeitiges Hochfahren von Pumpspeicher-Laden + Batterie-Laden + Elektrolyseur + Wärmepumpen → 162 MW Defizit-Burst, 4 Brownouts. H₂ über 12+ h mit 80–110 MW gefahren → leer vor Abendspitze. |
| 23 | Korrekte Bio+Geo-Volllast, aber H₂ ab Tick 80 leer; danach 16 weitere Brownouts unvermeidbar. |
| 42 | Strategiefehler: H₂-Round-Trip-Verlust (η ≈ 0.36) unterschätzt — jede MWh aus Turbine kostet ~1.8 MWh chemisch. H₂ leer gegen Mittag. |
| 99 | Aggressives Sektorkopplungs-Laden (5 Verbraucher gleichzeitig) Tick 44–52 → eigene Defizite, Speicher danach nicht voll genug für Abend. |

**Gemeinsame Lehre (zitierfähig):**
> *LLMs treffen lokal plausible Dispatch-Entscheidungen, scheitern aber an der globalen Energie-Budget-Planung über 24 h hinweg. Insbesondere die korrekte Bilanzierung eines Saison-Speichers (H₂) mit niedrigem Anfangs-SoC erfordert vorausschauende Reserven-Allokation, die der Block-Modus mit nur 1–2 h Voraussicht nicht leistet.*

---

## 6. Interpretation für die Seminararbeit

### 6.1 Hauptbefund
Die LLM-Steuerung **reduziert die Anzahl Brownout-Ticks signifikant** (52.8 vs. 65.0 bei `rule_based`, p < 0.001, |d| = 2.49). Die Forschungsfrage ist also in der **Brownout-Häufigkeit** zugunsten der KI zu beantworten.

### 6.2 Aber: Unserved Energy widerspricht
Trotz weniger Brownout-Ticks ist die **insgesamt nicht versorgte Energie** unter LLM-Steuerung fast 4× höher als bei `rule_based` (959 vs. 245 MWh). Die KI vermeidet zwar viele kleine Brownouts, hat aber **größere Defizit-Spitzen** (peak_deficit_mw ~164 vs. ~80 MW). Übersetzt: weniger, aber tiefere Versorgungslücken.

### 6.3 Frequenzstabilität (versteckter, aber wichtiger Befund)
- `rule_based` hält die Frequenz extrem stabil: max Δf = 0.40 Hz, nur ~5 Ticks außerhalb der Toleranzbande
- `claude_subagent` saturiert mehrfach bei der Begrenzung (Δf = 1.0 Hz), 62 Ticks außer Toleranz — vergleichbar mit `naive`
- → Aus **physikalischer** Perspektive (nicht nur energetischer) ist `rule_based` die deutlich überlegene Steuerung. Frequenzabweichungen > 0.5 Hz wären in einem realen Netz bereits Lastabwurf-Schwellen.

### 6.4 CO₂ und Renewable Share
- CO₂ unter Claude leicht erhöht (27.03 vs. 26.73 t, +1.1 %, signifikant aber klein)
- Renewable Share **niedriger** (52.3 vs. 57.3 %) — die LLM-Steuerung reduziert paradoxerweise den Anteil Erneuerbarer am gedeckten Bedarf, weil sie mehr fossile Backup-Reserven (H₂-GuD aus Importbrennstoff in der Bilanz) anwirft

### 6.5 Wirtschaftlichkeit
- `rule_based`: ~1.8 Mio EUR Tageskosten (LCOE ~415 EUR/MWh)
- `claude_subagent`: ~6.9 Mio EUR Tageskosten — fast 4× teurer, dominiert durch hohe VoLL-Kosten
- → In der Wirtschaftlichkeitsdimension ist `rule_based` klar überlegen

### 6.6 Differenzierte Antwort auf die Forschungsfrage

| Dimension | Sieger | Stärke des Effekts |
|---|---|---|
| Brownout-Häufigkeit | **Claude** | groß (d = -2.49) |
| Versorgungssicherheit (Unserved Energy) | **RuleBased** | sehr groß (d ≈ +9) |
| Frequenzstabilität | **RuleBased** | sehr groß |
| CO₂-Emissionen | RuleBased (knapp) | klein |
| Energieverschwendung (Surplus) | **RuleBased** | sehr groß (d = +11.8) |
| Wirtschaftlichkeit | **RuleBased** | sehr groß |
| Renewable Share | RuleBased (knapp) | mittel |

**Fazit:** Die LLM-Steuerung ist **nicht** überlegen. Sie zeigt eine isolierte Stärke bei der Brownout-Anzahl, fällt aber in fast allen anderen Dimensionen (besonders Frequenzstabilität, Unserved Energy, Surplus, Kosten) deutlich hinter eine simple regelbasierte Heuristik zurück. Die Hauptursache liegt in einem konkret benennbaren Strategiefehler (H₂-Speicher-Budget), der bei allen fünf unabhängigen Läufen reproduzierbar auftrat.

Diese differenzierte Antwort ist für die Seminararbeit besonders wertvoll, weil sie keine triviale "KI ist besser/schlechter"-Story erzwingt, sondern eine physikalisch und energetisch belastbare Diskussion der **Grenzen autonomer Sprachmodell-Steuerung in technischen Systemen** ermöglicht.

---

## 7. Reproduzierbarkeit

Alle Läufe sind deterministisch über `--seed` reproduzierbar. Die Reproducibility-Hashes (Tabelle 3.4) garantieren, dass identische Software-Version + Szenario + Seed + Controller exakt dieselben Ergebnisse liefern.

### Befehle zur Reproduktion der Baselines
```bash
for SEED in 7 13 23 42 99; do
    for CTRL in naive rule_based; do
        sgsim experiment run --controller $CTRL --seed $SEED --steps 96 \
            --out results/baselines/${CTRL}_seed${SEED}.csv
    done
done
```

### Reproduktion der Subagent-Läufe
LLM-Subagents sind **nicht deterministisch**, weil das LLM-Sampling nicht-deterministisch ist. Für eine 1:1-Reproduktion müssten Prompt + Modell + Temperatur + Random-Seed des LLMs fixiert werden — aktuell nicht möglich. Stattdessen liefern die Reproducibility-Hashes der Subagent-Läufe (oben) den Endzustand, gegen den ein neuer Lauf nur strukturell verglichen werden kann.

---

## 8. Datenanhang

### Pfade zu allen Rohdaten

| Inhalt | Pfad |
|---|---|
| Vollständige Metrik-Tabelle (CSV) | `results/pilot_summary/full_metrics.csv` |
| Aggregations-Output (Konsole) | `results/pilot_summary/aggregation.txt` |
| Dieser Bericht | `results/pilot_summary/bericht.md` |
| Baseline Tick-CSVs | `results/baselines/{naive,rule_based}_seed{7,13,23,42,99}.csv` |
| Baseline Sidecar-Metriken | `results/baselines/{naive,rule_based}_seed{7,13,23,42,99}.metrics.json` |
| Subagent Tick-CSVs | `runs/seed_{07,13,23,42,99}/result.csv` |
| Subagent Sidecar-Metriken | `runs/seed_{07,13,23,42,99}/result.metrics.json` |
| Subagent End-State | `runs/seed_{07,13,23,42,99}/.sgsim_state.json` |

### Plots (PNG, je 4 Diagramme: Generation Mix, SoC, Imbalance/CO₂, Tagesbilanz)

| Strategie (Seed 42) | Pfad |
|---|---|
| Naive | `results/baselines/plots/naive_seed42/` |
| RuleBased | `results/baselines/plots/rule_based_seed42/` |
| ClaudeSubagent | `runs/seed_42/plots/result/` |

Plots für andere Seeds erzeugen mit:
```bash
python3.12 scripts/plot_run.py <pfad-zur-tick-csv>
```

### Metrik-Definitionen (Auszug)

| Schlüssel | Bedeutung |
|---|---|
| `brownout_steps` | Anzahl Ticks mit `imbalance < 0` (Defizit) |
| `unserved_energy_mwh` | Σ |min(0, imbalance)| × Δt — gesamte unversorgte Energie |
| `surplus_energy_mwh` | Σ max(0, imbalance) × Δt — überschüssige Energie (verworfen wenn Speicher voll) |
| `peak_deficit_mw` | Maximales Momentan-Defizit über alle Ticks |
| `max_frequency_deviation_hz` | Maximale |f − 50 Hz| über alle Ticks |
| `ticks_outside_freq_dead_band` | Anzahl Ticks mit |Δf| > 0.05 Hz |
| `co2_kg_per_mwh_demand` | CO₂-Intensität pro MWh gedeckte Nachfrage |
| `renewable_share_of_demand` | Anteil Erneuerbarer am tatsächlich gedeckten Bedarf |
| `voll_cost_eur` | Value of Lost Load (Schaden durch Brownouts) — 7000 EUR/MWh |
| `lcoe_eur_per_mwh` | Levelized Cost of Energy pro gedeckte MWh |

Vollständige Definitionen: `docs/methodology.md` (besonders §11 zur Wirtschaftlichkeit).

---

*Bericht generiert am 2026-05-02 aus 15 vollständigen Simulationsläufen.*
